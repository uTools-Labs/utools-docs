import clientAppSetup0 from '/Users/dto/www/yuanli/utools-docs/node_modules/@vuepress/plugin-active-header-links/lib/client/clientAppSetup.js'
import clientAppSetup1 from '/Users/dto/www/yuanli/utools-docs/node_modules/@vuepress/plugin-nprogress/lib/client/clientAppSetup.js'
import clientAppSetup2 from '/Users/dto/www/yuanli/utools-docs/node_modules/@vuepress/theme-default/lib/client/clientAppSetup.js'

export const clientAppSetups = [
  clientAppSetup0,
  clientAppSetup1,
  clientAppSetup2,
]
