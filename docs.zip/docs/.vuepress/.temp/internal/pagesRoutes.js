import { Vuepress } from '@vuepress/client/lib/components/Vuepress'

const routeItems = [
  ["v-7e757cd5","/terms_dev.html",{"title":"uTools 开发者协议"},["/terms_dev","/terms_dev.md"]],
  ["v-0955acc2","/terms_privacy.html",{"title":"uTools 隐私政策"},["/terms_privacy","/terms_privacy.md"]],
  ["v-76c241c6","/terms_user.html",{"title":"uTools 用户协议"},["/terms_user","/terms_user.md"]],
  ["v-a1b7ab46","/developer/api.html",{"title":"uTools API"},["/developer/api","/developer/api.md"]],
  ["v-4f98fc52","/developer/best.html",{"title":"注意事项"},["/developer/best","/developer/best.md"]],
  ["v-50f52eb9","/developer/config.html",{"title":"完整配置"},["/developer/config","/developer/config.md"]],
  ["v-ed5f6806","/developer/db.html",{"title":"uTools DB API"},["/developer/db","/developer/db.md"]],
  ["v-3d82b21e","/developer/payment.html",{"title":"插件内收款服务"},["/developer/payment","/developer/payment.md"]],
  ["v-5e3a74ce","/developer/preload.html",{"title":"preload.js"},["/developer/preload","/developer/preload.md"]],
  ["v-4393cd2b","/developer/server-api.html",{"title":"uTools Server API"},["/developer/server-api","/developer/server-api.md"]],
  ["v-23a07801","/developer/template.html",{"title":"模板插件应用"},["/developer/template","/developer/template.md"]],
  ["v-ce97e1f0","/developer/ubrowser.html",{"title":"ubrowser API"},["/developer/ubrowser","/developer/ubrowser.md"]],
  ["v-0eda91d6","/developer/welcome.html",{"title":"快速上手"},["/developer/welcome","/developer/welcome.md"]],
  ["v-e4f906f2","/guide/about-uTools.html",{"title":"介绍"},["/guide/about-uTools","/guide/about-uTools.md"]],
  ["v-134158a8","/guide/enterprise.html",{"title":"企业服务"},["/guide/enterprise","/guide/enterprise.md"]],
  ["v-37e1c06f","/guide/faq.html",{"title":"常见问题"},["/guide/faq","/guide/faq.md"]],
  ["v-654983d1","/guide/ppt.html",{"title":"向团队介绍 uTools"},["/guide/ppt","/guide/ppt.md"]],
  ["v-7bb1f374","/guide/share.html",{"title":"限时活动"},["/guide/share","/guide/share.md"]],
  ["v-7745d56b","/guide/skills.html",{"title":"使用技巧"},["/guide/skills","/guide/skills.md"]],
  ["v-9edff62a","/guide/sponsor.html",{"title":"如何与我们合作？"},["/guide/sponsor","/guide/sponsor.md"]],
  ["v-3706649a","/404.html",{"title":""},["/404"]],
]

export const pagesRoutes = routeItems.reduce(
  (result, [name, path, meta, redirects]) => {
    result.push(
      {
        name,
        path,
        component: Vuepress,
        meta,
      },
      ...redirects.map((item) => ({
        path: item,
        redirect: path,
      }))
    )
    return result
  },
  [
    {
      name: "404",
      path: "/:catchAll(.*)",
      component: Vuepress,
    }
  ]
)
