export const searchIndex = [
  {
    "title": "uTools 开发者协议",
    "headers": [],
    "path": "/terms_dev.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "uTools 隐私政策",
    "headers": [
      {
        "level": 3,
        "title": "1.定义",
        "slug": "_1-定义",
        "children": []
      },
      {
        "level": 3,
        "title": "2. 我方如何收集和使用个人信息",
        "slug": "_2-我方如何收集和使用个人信息",
        "children": []
      },
      {
        "level": 3,
        "title": "3. 我方如何使用Cookie等同类技术",
        "slug": "_3-我方如何使用cookie等同类技术",
        "children": []
      },
      {
        "level": 3,
        "title": "4. 我方如何共享、转让、公开披露个人信息",
        "slug": "_4-我方如何共享、转让、公开披露个人信息",
        "children": []
      },
      {
        "level": 3,
        "title": "5. 我方如何存储个人信息",
        "slug": "_5-我方如何存储个人信息",
        "children": []
      },
      {
        "level": 3,
        "title": "6. 我方如何保护个人信息的安全",
        "slug": "_6-我方如何保护个人信息的安全",
        "children": []
      },
      {
        "level": 3,
        "title": "7. 您如何管理您的个人信息",
        "slug": "_7-您如何管理您的个人信息",
        "children": []
      },
      {
        "level": 3,
        "title": "8. 未成年人条款",
        "slug": "_8-未成年人条款",
        "children": []
      },
      {
        "level": 3,
        "title": "9. 隐私政策的修订和通知",
        "slug": "_9-隐私政策的修订和通知",
        "children": []
      },
      {
        "level": 3,
        "title": "10. 其他",
        "slug": "_10-其他",
        "children": []
      },
      {
        "level": 3,
        "title": "11. 联系我方",
        "slug": "_11-联系我方",
        "children": []
      }
    ],
    "path": "/terms_privacy.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "uTools 用户协议",
    "headers": [],
    "path": "/terms_user.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "uTools API",
    "headers": [
      {
        "level": 2,
        "title": "事件",
        "slug": "事件",
        "children": [
          {
            "level": 3,
            "title": "onPluginEnter(callback)",
            "slug": "onpluginenter-callback",
            "children": []
          },
          {
            "level": 3,
            "title": "onPluginOut(callback)",
            "slug": "onpluginout-callback",
            "children": []
          },
          {
            "level": 3,
            "title": "onPluginDetach(callback)",
            "slug": "onplugindetach-callback",
            "children": []
          },
          {
            "level": 3,
            "title": "onDbPull(callback)",
            "slug": "ondbpull-callback",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "窗口交互",
        "slug": "窗口交互",
        "children": [
          {
            "level": 3,
            "title": "hideMainWindow(isRestorePreWindow)",
            "slug": "hidemainwindow-isrestoreprewindow",
            "children": []
          },
          {
            "level": 3,
            "title": "showMainWindow()",
            "slug": "showmainwindow",
            "children": []
          },
          {
            "level": 3,
            "title": "setExpendHeight(height)",
            "slug": "setexpendheight-height",
            "children": []
          },
          {
            "level": 3,
            "title": "setSubInput(onChange, placeholder, isFocus)",
            "slug": "setsubinput-onchange-placeholder-isfocus",
            "children": []
          },
          {
            "level": 3,
            "title": "removeSubInput()",
            "slug": "removesubinput",
            "children": []
          },
          {
            "level": 3,
            "title": "setSubInputValue(value)",
            "slug": "setsubinputvalue-value",
            "children": []
          },
          {
            "level": 3,
            "title": "subInputFocus()",
            "slug": "subinputfocus",
            "children": []
          },
          {
            "level": 3,
            "title": "subInputSelect()",
            "slug": "subinputselect",
            "children": []
          },
          {
            "level": 3,
            "title": "subInputBlur()",
            "slug": "subinputblur",
            "children": []
          },
          {
            "level": 3,
            "title": "outPlugin()",
            "slug": "outplugin",
            "children": []
          },
          {
            "level": 3,
            "title": "redirect(label, payload)",
            "slug": "redirect-label-payload",
            "children": []
          },
          {
            "level": 3,
            "title": "showOpenDialog(options)",
            "slug": "showopendialog-options",
            "children": []
          },
          {
            "level": 3,
            "title": "showSaveDialog(options)",
            "slug": "showsavedialog-options",
            "children": []
          },
          {
            "level": 3,
            "title": "findInPage(text, options)",
            "slug": "findinpage-text-options",
            "children": []
          },
          {
            "level": 3,
            "title": "stopFindInPage(action)",
            "slug": "stopfindinpage-action",
            "children": []
          },
          {
            "level": 3,
            "title": "startDrag(file)",
            "slug": "startdrag-file",
            "children": []
          },
          {
            "level": 3,
            "title": "createBrowserWindow(url, options, callback)",
            "slug": "createbrowserwindow-url-options-callback",
            "children": []
          },
          {
            "level": 3,
            "title": "isDarkColors()",
            "slug": "isdarkcolors",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "动态增减功能",
        "slug": "动态增减功能",
        "children": [
          {
            "level": 3,
            "title": "getFeatures(codes)",
            "slug": "getfeatures-codes",
            "children": []
          },
          {
            "level": 3,
            "title": "setFeature(feature)",
            "slug": "setfeature-feature",
            "children": []
          },
          {
            "level": 3,
            "title": "removeFeature(code)",
            "slug": "removefeature-code",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "用户",
        "slug": "用户",
        "children": [
          {
            "level": 3,
            "title": "getUser()",
            "slug": "getuser",
            "children": []
          },
          {
            "level": 3,
            "title": "fetchUserServerTemporaryToken()",
            "slug": "fetchuserservertemporarytoken",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "支付",
        "slug": "支付",
        "children": [
          {
            "level": 3,
            "title": "openPayment(options, callback)",
            "slug": "openpayment-options-callback",
            "children": []
          },
          {
            "level": 3,
            "title": "fetchUserPayments()",
            "slug": "fetchuserpayments",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "工具",
        "slug": "工具",
        "children": [
          {
            "level": 3,
            "title": "screenColorPick(callback)",
            "slug": "screencolorpick-callback",
            "children": []
          },
          {
            "level": 3,
            "title": "screenCapture(callback)",
            "slug": "screencapture-callback",
            "children": []
          },
          {
            "level": 3,
            "title": "hideMainWindowTypeString(text)",
            "slug": "hidemainwindowtypestring-text",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "模拟",
        "slug": "模拟",
        "children": [
          {
            "level": 3,
            "title": "simulateKeyboardTap(key, ...modifier)",
            "slug": "simulatekeyboardtap-key-modifier",
            "children": []
          },
          {
            "level": 3,
            "title": "simulateMouseMove(x, y)",
            "slug": "simulatemousemove-x-y",
            "children": []
          },
          {
            "level": 3,
            "title": "simulateMouseClick(x, y)",
            "slug": "simulatemouseclick-x-y",
            "children": []
          },
          {
            "level": 3,
            "title": "simulateMouseRightClick(x, y)",
            "slug": "simulatemouserightclick-x-y",
            "children": []
          },
          {
            "level": 3,
            "title": "simulateMouseDoubleClick(x, y)",
            "slug": "simulatemousedoubleclick-x-y",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "屏幕",
        "slug": "屏幕",
        "children": [
          {
            "level": 3,
            "title": "getCursorScreenPoint()",
            "slug": "getcursorscreenpoint",
            "children": []
          },
          {
            "level": 3,
            "title": "getPrimaryDisplay()",
            "slug": "getprimarydisplay",
            "children": []
          },
          {
            "level": 3,
            "title": "getAllDisplays()",
            "slug": "getalldisplays",
            "children": []
          },
          {
            "level": 3,
            "title": "getDisplayNearestPoint(point)",
            "slug": "getdisplaynearestpoint-point",
            "children": []
          },
          {
            "level": 3,
            "title": "getDisplayMatching(rect)",
            "slug": "getdisplaymatching-rect",
            "children": []
          },
          {
            "level": 3,
            "title": "desktopCaptureSources(options)",
            "slug": "desktopcapturesources-options",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "复制",
        "slug": "复制",
        "children": [
          {
            "level": 3,
            "title": "copyFile(file)",
            "slug": "copyfile-file",
            "children": []
          },
          {
            "level": 3,
            "title": "copyImage(img)",
            "slug": "copyimage-img",
            "children": []
          },
          {
            "level": 3,
            "title": "copyText(text)",
            "slug": "copytext-text",
            "children": []
          },
          {
            "level": 3,
            "title": "getCopyedFiles()",
            "slug": "getcopyedfiles",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "系统",
        "slug": "系统",
        "children": [
          {
            "level": 3,
            "title": "showNotification(body, clickFeatureCode)",
            "slug": "shownotification-body-clickfeaturecode",
            "children": []
          },
          {
            "level": 3,
            "title": "shellOpenPath(fullPath)",
            "slug": "shellopenpath-fullpath",
            "children": []
          },
          {
            "level": 3,
            "title": "shellShowItemInFolder(fullPath)",
            "slug": "shellshowiteminfolder-fullpath",
            "children": []
          },
          {
            "level": 3,
            "title": "shellOpenExternal(url)",
            "slug": "shellopenexternal-url",
            "children": []
          },
          {
            "level": 3,
            "title": "shellBeep()",
            "slug": "shellbeep",
            "children": []
          },
          {
            "level": 3,
            "title": "getNativeId()",
            "slug": "getnativeid",
            "children": []
          },
          {
            "level": 3,
            "title": "getAppVersion()",
            "slug": "getappversion",
            "children": []
          },
          {
            "level": 3,
            "title": "getPath(name)",
            "slug": "getpath-name",
            "children": []
          },
          {
            "level": 3,
            "title": "getFileIcon(filePath)",
            "slug": "getfileicon-filepath",
            "children": []
          },
          {
            "level": 3,
            "title": "readCurrentFolderPath()",
            "slug": "readcurrentfolderpath",
            "children": []
          },
          {
            "level": 3,
            "title": "readCurrentBrowserUrl()",
            "slug": "readcurrentbrowserurl",
            "children": []
          },
          {
            "level": 3,
            "title": "isDev()",
            "slug": "isdev",
            "children": []
          },
          {
            "level": 3,
            "title": "isMacOS()",
            "slug": "ismacos",
            "children": []
          },
          {
            "level": 3,
            "title": "isWindows()",
            "slug": "iswindows",
            "children": []
          },
          {
            "level": 3,
            "title": "isLinux()",
            "slug": "islinux",
            "children": []
          }
        ]
      }
    ],
    "path": "/developer/api.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "注意事项",
    "headers": [],
    "path": "/developer/best.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "完整配置",
    "headers": [
      {
        "level": 2,
        "title": "基本配置",
        "slug": "基本配置",
        "children": [
          {
            "level": 3,
            "title": "main",
            "slug": "main",
            "children": []
          },
          {
            "level": 3,
            "title": "preload",
            "slug": "preload",
            "children": []
          },
          {
            "level": 3,
            "title": "logo",
            "slug": "logo",
            "children": []
          },
          {
            "level": 3,
            "title": "platform",
            "slug": "platform",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "开发模式",
        "slug": "开发模式",
        "children": [
          {
            "level": 3,
            "title": "development",
            "slug": "development",
            "children": []
          },
          {
            "level": 3,
            "title": "development.main",
            "slug": "development-main",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "插件应用设置",
        "slug": "插件应用设置",
        "children": [
          {
            "level": 3,
            "title": "pluginSetting",
            "slug": "pluginsetting",
            "children": []
          },
          {
            "level": 3,
            "title": "pluginSetting.single",
            "slug": "pluginsetting-single",
            "children": []
          },
          {
            "level": 3,
            "title": "pluginSetting.height",
            "slug": "pluginsetting-height",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "插件应用功能",
        "slug": "插件应用功能",
        "children": [
          {
            "level": 3,
            "title": "features",
            "slug": "features",
            "children": []
          },
          {
            "level": 3,
            "title": "features.code",
            "slug": "features-code",
            "children": []
          },
          {
            "level": 3,
            "title": "features.explain",
            "slug": "features-explain",
            "children": []
          },
          {
            "level": 3,
            "title": "features.icon",
            "slug": "features-icon",
            "children": []
          },
          {
            "level": 3,
            "title": "features.platform",
            "slug": "features-platform",
            "children": []
          },
          {
            "level": 3,
            "title": "features.cmds",
            "slug": "features-cmds",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "完整配置下载",
        "slug": "完整配置下载",
        "children": []
      }
    ],
    "path": "/developer/config.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "uTools DB API",
    "headers": [
      {
        "level": 2,
        "title": "本地数据库",
        "slug": "本地数据库",
        "children": [
          {
            "level": 3,
            "title": "utools.db.put(doc)",
            "slug": "utools-db-put-doc",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.get(id)",
            "slug": "utools-db-get-id",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.remove(doc)",
            "slug": "utools-db-remove-doc",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.bulkDocs(docs)",
            "slug": "utools-db-bulkdocs-docs",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.allDocs(key)",
            "slug": "utools-db-alldocs-key",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.postAttachment(docId, attachment, type)",
            "slug": "utools-db-postattachment-docid-attachment-type",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.getAttachment(docId)",
            "slug": "utools-db-getattachment-docid",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.getAttachmentType(docId)",
            "slug": "utools-db-getattachmenttype-docid",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.db.replicateStateFromCloud()",
            "slug": "utools-db-replicatestatefromcloud",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "dbStorage",
        "slug": "dbstorage",
        "children": [
          {
            "level": 3,
            "title": "utools.dbStorage.setItem(key, value)",
            "slug": "utools-dbstorage-setitem-key-value",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.dbStorage.getItem(key)",
            "slug": "utools-dbstorage-getitem-key",
            "children": []
          },
          {
            "level": 3,
            "title": "utools.dbStorage.removeItem(key)",
            "slug": "utools-dbstorage-removeitem-key",
            "children": []
          }
        ]
      }
    ],
    "path": "/developer/db.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "插件内收款服务",
    "headers": [],
    "path": "/developer/payment.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "preload.js",
    "headers": [],
    "path": "/developer/preload.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "uTools Server API",
    "headers": [
      {
        "level": 2,
        "title": "获取用户基础信息接口",
        "slug": "获取用户基础信息接口",
        "children": [
          {
            "level": 3,
            "title": "1.1 接口说明",
            "slug": "_1-1-接口说明",
            "children": []
          },
          {
            "level": 3,
            "title": "1.2 获取当前用户临时 access_token",
            "slug": "_1-2-获取当前用户临时-access-token",
            "children": []
          },
          {
            "level": 3,
            "title": "1.3 签名方法",
            "slug": "_1-3-签名方法",
            "children": []
          },
          {
            "level": 3,
            "title": "1.4 返回值",
            "slug": "_1-4-返回值",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "用户支付成功回调接口",
        "slug": "用户支付成功回调接口",
        "children": [
          {
            "level": 3,
            "title": "2.1 接口说明",
            "slug": "_2-1-接口说明",
            "children": []
          },
          {
            "level": 3,
            "title": "2.2 注意事项",
            "slug": "_2-2-注意事项",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "支付订单查询接口",
        "slug": "支付订单查询接口",
        "children": [
          {
            "level": 3,
            "title": "3.2 返回值",
            "slug": "_3-2-返回值",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "创建商品接口",
        "slug": "创建商品接口",
        "children": [
          {
            "level": 3,
            "title": "3.2 返回值",
            "slug": "_3-2-返回值-1",
            "children": []
          }
        ]
      }
    ],
    "path": "/developer/server-api.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "模板插件应用",
    "headers": [
      {
        "level": 2,
        "title": "plugin.json 文件",
        "slug": "plugin-json-文件",
        "children": []
      },
      {
        "level": 2,
        "title": "preload.js 文件",
        "slug": "preload-js-文件",
        "children": [
          {
            "level": 3,
            "title": "无 UI 模式",
            "slug": "无-ui-模式",
            "children": []
          },
          {
            "level": 3,
            "title": "列表模式",
            "slug": "列表模式",
            "children": []
          },
          {
            "level": 3,
            "title": "文档模式",
            "slug": "文档模式",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "示例项目",
        "slug": "示例项目",
        "children": [
          {
            "level": 3,
            "title": "无 UI + 列表模式",
            "slug": "无-ui-列表模式",
            "children": []
          },
          {
            "level": 3,
            "title": "文档模式",
            "slug": "文档模式-1",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "UI 展示",
        "slug": "ui-展示",
        "children": []
      }
    ],
    "path": "/developer/template.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "ubrowser API",
    "headers": [
      {
        "level": 2,
        "title": "API 列表",
        "slug": "api-列表",
        "children": [
          {
            "level": 3,
            "title": "useragent(userAgent)",
            "slug": "useragent-useragent",
            "children": []
          },
          {
            "level": 3,
            "title": "goto(url, headers, timeout)",
            "slug": "goto-url-headers-timeout",
            "children": []
          },
          {
            "level": 3,
            "title": "viewport(width, height)",
            "slug": "viewport-width-height",
            "children": []
          },
          {
            "level": 3,
            "title": "hide()",
            "slug": "hide",
            "children": []
          },
          {
            "level": 3,
            "title": "show()",
            "slug": "show",
            "children": []
          },
          {
            "level": 3,
            "title": "css(cssCode)",
            "slug": "css-csscode",
            "children": []
          },
          {
            "level": 3,
            "title": "press(key, ...modifier)",
            "slug": "press-key-modifier",
            "children": []
          },
          {
            "level": 3,
            "title": "paste(text)",
            "slug": "paste-text",
            "children": []
          },
          {
            "level": 3,
            "title": "screenshot(arg, savePath)",
            "slug": "screenshot-arg-savepath",
            "children": []
          },
          {
            "level": 3,
            "title": "pdf(options, savePath)",
            "slug": "pdf-options-savepath",
            "children": []
          },
          {
            "level": 3,
            "title": "device(arg)",
            "slug": "device-arg",
            "children": []
          },
          {
            "level": 3,
            "title": "cookies(name)",
            "slug": "cookies-name",
            "children": []
          },
          {
            "level": 3,
            "title": "setCookies(name, value)",
            "slug": "setcookies-name-value",
            "children": []
          },
          {
            "level": 3,
            "title": "setCookies(cookies)",
            "slug": "setcookies-cookies",
            "children": []
          },
          {
            "level": 3,
            "title": "removeCookies(name)",
            "slug": "removecookies-name",
            "children": []
          },
          {
            "level": 3,
            "title": "clearCookies(url)",
            "slug": "clearcookies-url",
            "children": []
          },
          {
            "level": 3,
            "title": "devTools(mode)",
            "slug": "devtools-mode",
            "children": []
          },
          {
            "level": 3,
            "title": "evaluate(func, ...params)",
            "slug": "evaluate-func-params",
            "children": []
          },
          {
            "level": 3,
            "title": "wait(ms)",
            "slug": "wait-ms",
            "children": []
          },
          {
            "level": 3,
            "title": "wait(selector, timeout)",
            "slug": "wait-selector-timeout",
            "children": []
          },
          {
            "level": 3,
            "title": "wait(func, timeout，...params)",
            "slug": "wait-func-timeout-params",
            "children": []
          },
          {
            "level": 3,
            "title": "when(selector)",
            "slug": "when-selector",
            "children": []
          },
          {
            "level": 3,
            "title": "when(func, ...params)",
            "slug": "when-func-params",
            "children": []
          },
          {
            "level": 3,
            "title": "end()",
            "slug": "end",
            "children": []
          },
          {
            "level": 3,
            "title": "click(selector)",
            "slug": "click-selector",
            "children": []
          },
          {
            "level": 3,
            "title": "mousedown(selector)",
            "slug": "mousedown-selector",
            "children": []
          },
          {
            "level": 3,
            "title": "mouseup(selector)",
            "slug": "mouseup-selector",
            "children": []
          },
          {
            "level": 3,
            "title": "file(selector, payload)",
            "slug": "file-selector-payload",
            "children": []
          },
          {
            "level": 3,
            "title": "value(selector, val)",
            "slug": "value-selector-val",
            "children": []
          },
          {
            "level": 3,
            "title": "check(selector, checked)",
            "slug": "check-selector-checked",
            "children": []
          },
          {
            "level": 3,
            "title": "focus(selector)",
            "slug": "focus-selector",
            "children": []
          },
          {
            "level": 3,
            "title": "scroll(selector)",
            "slug": "scroll-selector",
            "children": []
          },
          {
            "level": 3,
            "title": "scroll(y)",
            "slug": "scroll-y",
            "children": []
          },
          {
            "level": 3,
            "title": "scroll(x, y)",
            "slug": "scroll-x-y",
            "children": []
          },
          {
            "level": 3,
            "title": "run(ubrowserId)",
            "slug": "run-ubrowserid",
            "children": []
          },
          {
            "level": 3,
            "title": "run(options)",
            "slug": "run-options",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "ubrowser 管理",
        "slug": "ubrowser-管理",
        "children": [
          {
            "level": 3,
            "title": "getIdleUBrowsers()",
            "slug": "getidleubrowsers",
            "children": []
          },
          {
            "level": 3,
            "title": "setUBrowserProxy(config)",
            "slug": "setubrowserproxy-config",
            "children": []
          },
          {
            "level": 3,
            "title": "clearUBrowserCache()",
            "slug": "clearubrowsercache",
            "children": []
          }
        ]
      }
    ],
    "path": "/developer/ubrowser.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "快速上手",
    "headers": [
      {
        "level": 2,
        "title": "plugin.json",
        "slug": "plugin-json",
        "children": []
      },
      {
        "level": 2,
        "title": "开发者中心",
        "slug": "开发者中心",
        "children": []
      }
    ],
    "path": "/developer/welcome.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "介绍",
    "headers": [
      {
        "level": 2,
        "title": "uTools 是什么？",
        "slug": "utools-是什么",
        "children": []
      },
      {
        "level": 2,
        "title": "uTools 能做什么？",
        "slug": "utools-能做什么",
        "children": []
      },
      {
        "level": 2,
        "title": "一切皆插件！",
        "slug": "一切皆插件",
        "children": []
      },
      {
        "level": 2,
        "title": "超级面板",
        "slug": "超级面板",
        "children": []
      },
      {
        "level": 2,
        "title": "uTools 和 「猿料」 是什么关系？",
        "slug": "utools-和-「猿料」-是什么关系",
        "children": []
      },
      {
        "level": 2,
        "title": "联系方式",
        "slug": "联系方式",
        "children": []
      }
    ],
    "path": "/guide/about-uTools.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "企业服务",
    "headers": [
      {
        "level": 3,
        "title": "企业定制版",
        "slug": "企业定制版",
        "children": []
      },
      {
        "level": 3,
        "title": "企业内网部署",
        "slug": "企业内网部署",
        "children": []
      }
    ],
    "path": "/guide/enterprise.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "常见问题",
    "headers": [
      {
        "level": 3,
        "title": "安装时遇到了「无法打开 uTools，因为 Apple 无法检查是否包含恶意软体」的情况怎么办？",
        "slug": "安装时遇到了「无法打开-utools-因为-apple-无法检查是否包含恶意软体」的情况怎么办",
        "children": []
      },
      {
        "level": 3,
        "title": "uTools 会收费吗？",
        "slug": "utools-会收费吗",
        "children": []
      },
      {
        "level": 3,
        "title": "购买 uTools 会员后可以开发票吗？",
        "slug": "购买-utools-会员后可以开发票吗",
        "children": []
      },
      {
        "level": 3,
        "title": "可以在公司环境使用吗？",
        "slug": "可以在公司环境使用吗",
        "children": []
      },
      {
        "level": 3,
        "title": "为什么任务管理器中会有这么多名为「uTools」的进程？",
        "slug": "为什么任务管理器中会有这么多名为「utools」的进程",
        "children": []
      },
      {
        "level": 3,
        "title": "安装时遇到了「进度条卡在一半」的情况怎么办？",
        "slug": "安装时遇到了「进度条卡在一半」的情况怎么办",
        "children": []
      },
      {
        "level": 3,
        "title": "uTools 是否会开源？",
        "slug": "utools-是否会开源",
        "children": []
      }
    ],
    "path": "/guide/faq.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "向团队介绍 uTools",
    "headers": [
      {
        "level": 3,
        "title": "播放 uTools 介绍视频",
        "slug": "播放-utools-介绍视频",
        "children": []
      },
      {
        "level": 3,
        "title": "分享过程中可供使用的 PPT",
        "slug": "分享过程中可供使用的-ppt",
        "children": []
      },
      {
        "level": 3,
        "title": "演示你在工作中如何使用 uTools",
        "slug": "演示你在工作中如何使用-utools",
        "children": []
      }
    ],
    "path": "/guide/ppt.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "限时活动",
    "headers": [
      {
        "level": 2,
        "title": "【活动一】uTools 推荐计划",
        "slug": "【活动一】utools-推荐计划",
        "children": [
          {
            "level": 3,
            "title": "计划详情",
            "slug": "计划详情",
            "children": []
          },
          {
            "level": 3,
            "title": "计算原理",
            "slug": "计算原理",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "【活动二】秀心得，获得免费会员",
        "slug": "【活动二】秀心得-获得免费会员",
        "children": [
          {
            "level": 3,
            "title": "撰写你的原创深度心得文章",
            "slug": "撰写你的原创深度心得文章",
            "children": []
          },
          {
            "level": 3,
            "title": "活动流程：",
            "slug": "活动流程",
            "children": []
          },
          {
            "level": 3,
            "title": "评审原则与配分",
            "slug": "评审原则与配分",
            "children": []
          },
          {
            "level": 3,
            "title": "奖励",
            "slug": "奖励",
            "children": []
          },
          {
            "level": 3,
            "title": "注意事项",
            "slug": "注意事项",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/share.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "使用技巧",
    "headers": [
      {
        "level": 2,
        "title": "ESC 键 快速回到主输入框",
        "slug": "esc-键-快速回到主输入框",
        "children": []
      },
      {
        "level": 2,
        "title": "窗口分离",
        "slug": "窗口分离",
        "children": []
      },
      {
        "level": 2,
        "title": "自动识别",
        "slug": "自动识别",
        "children": []
      },
      {
        "level": 2,
        "title": "使用「管理员」权限运行软件",
        "slug": "使用「管理员」权限运行软件",
        "children": []
      },
      {
        "level": 2,
        "title": "将绿色软件加入到 uTools 快速搜索",
        "slug": "将绿色软件加入到-utools-快速搜索",
        "children": []
      },
      {
        "level": 2,
        "title": "全局快捷键",
        "slug": "全局快捷键",
        "children": []
      },
      {
        "level": 2,
        "title": "数据同步",
        "slug": "数据同步",
        "children": []
      }
    ],
    "path": "/guide/skills.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "如何与我们合作？",
    "headers": [
      {
        "level": 3,
        "title": "活动赞助",
        "slug": "活动赞助",
        "children": []
      },
      {
        "level": 3,
        "title": "商业合作",
        "slug": "商业合作",
        "children": []
      }
    ],
    "path": "/guide/sponsor.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/404.html",
    "pathLocale": "/",
    "extraFields": []
  }
]
