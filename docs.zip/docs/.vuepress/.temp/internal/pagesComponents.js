import { defineAsyncComponent } from 'vue'

export const pagesComponents = {
  // path: /terms_dev.html
  "v-7e757cd5": defineAsyncComponent(() => import(/* webpackChunkName: "v-7e757cd5" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/terms_dev.html.vue")),
  // path: /terms_privacy.html
  "v-0955acc2": defineAsyncComponent(() => import(/* webpackChunkName: "v-0955acc2" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/terms_privacy.html.vue")),
  // path: /terms_user.html
  "v-76c241c6": defineAsyncComponent(() => import(/* webpackChunkName: "v-76c241c6" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/terms_user.html.vue")),
  // path: /developer/api.html
  "v-a1b7ab46": defineAsyncComponent(() => import(/* webpackChunkName: "v-a1b7ab46" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/api.html.vue")),
  // path: /developer/best.html
  "v-4f98fc52": defineAsyncComponent(() => import(/* webpackChunkName: "v-4f98fc52" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/best.html.vue")),
  // path: /developer/config.html
  "v-50f52eb9": defineAsyncComponent(() => import(/* webpackChunkName: "v-50f52eb9" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/config.html.vue")),
  // path: /developer/db.html
  "v-ed5f6806": defineAsyncComponent(() => import(/* webpackChunkName: "v-ed5f6806" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/db.html.vue")),
  // path: /developer/payment.html
  "v-3d82b21e": defineAsyncComponent(() => import(/* webpackChunkName: "v-3d82b21e" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/payment.html.vue")),
  // path: /developer/preload.html
  "v-5e3a74ce": defineAsyncComponent(() => import(/* webpackChunkName: "v-5e3a74ce" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/preload.html.vue")),
  // path: /developer/server-api.html
  "v-4393cd2b": defineAsyncComponent(() => import(/* webpackChunkName: "v-4393cd2b" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/server-api.html.vue")),
  // path: /developer/template.html
  "v-23a07801": defineAsyncComponent(() => import(/* webpackChunkName: "v-23a07801" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/template.html.vue")),
  // path: /developer/ubrowser.html
  "v-ce97e1f0": defineAsyncComponent(() => import(/* webpackChunkName: "v-ce97e1f0" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/ubrowser.html.vue")),
  // path: /developer/welcome.html
  "v-0eda91d6": defineAsyncComponent(() => import(/* webpackChunkName: "v-0eda91d6" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/developer/welcome.html.vue")),
  // path: /guide/about-uTools.html
  "v-e4f906f2": defineAsyncComponent(() => import(/* webpackChunkName: "v-e4f906f2" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/guide/about-uTools.html.vue")),
  // path: /guide/enterprise.html
  "v-134158a8": defineAsyncComponent(() => import(/* webpackChunkName: "v-134158a8" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/guide/enterprise.html.vue")),
  // path: /guide/faq.html
  "v-37e1c06f": defineAsyncComponent(() => import(/* webpackChunkName: "v-37e1c06f" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/guide/faq.html.vue")),
  // path: /guide/ppt.html
  "v-654983d1": defineAsyncComponent(() => import(/* webpackChunkName: "v-654983d1" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/guide/ppt.html.vue")),
  // path: /guide/share.html
  "v-7bb1f374": defineAsyncComponent(() => import(/* webpackChunkName: "v-7bb1f374" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/guide/share.html.vue")),
  // path: /guide/skills.html
  "v-7745d56b": defineAsyncComponent(() => import(/* webpackChunkName: "v-7745d56b" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/guide/skills.html.vue")),
  // path: /guide/sponsor.html
  "v-9edff62a": defineAsyncComponent(() => import(/* webpackChunkName: "v-9edff62a" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/guide/sponsor.html.vue")),
  // path: /404.html
  "v-3706649a": defineAsyncComponent(() => import(/* webpackChunkName: "v-3706649a" */"/Users/dto/www/yuanli/utools-docs/docs/.vuepress/.temp/pages/404.html.vue")),
}
