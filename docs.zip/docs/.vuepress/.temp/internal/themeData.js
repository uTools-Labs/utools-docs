export const themeData = {
  "logoDark": "https://res.u-tools.cn/website/white.png",
  "logo": "https://res.u-tools.cn/website/logo.png",
  "lastUpdated": false,
  "contributors": false,
  "sidebarDepth": 1,
  "home": "/guide/about-uTools.html",
  "navbar": [
    {
      "text": "使用指南",
      "link": "/guide/about-uTools",
      "activeMatch": "/guide/"
    },
    {
      "text": "插件开发",
      "link": "/developer/welcome",
      "activeMatch": "/developer/"
    },
    {
      "text": "uTools 官网",
      "link": "https://u.tools"
    },
    {
      "text": "社区",
      "link": "https://yuanliao.info"
    }
  ],
  "sidebar": {
    "/guide/": [
      {
        "text": "用户指南",
        "children": [
          "/guide/about-uTools",
          "/guide/skills",
          "/guide/share",
          "/guide/ppt",
          "/guide/enterprise",
          "/guide/faq"
        ]
      }
    ],
    "/developer/": [
      {
        "text": "插件开发",
        "children": [
          "/developer/welcome",
          "/developer/config",
          "/developer/preload",
          "/developer/template",
          "/developer/api",
          "/developer/db",
          "/developer/ubrowser",
          "/developer/server-api",
          "/developer/payment",
          "/developer/best"
        ]
      }
    ]
  },
  "locales": {
    "/": {
      "selectLanguageName": "English"
    }
  },
  "darkMode": true,
  "repo": null,
  "selectLanguageText": "Languages",
  "selectLanguageAriaLabel": "Select language",
  "editLink": true,
  "editLinkText": "Edit this page",
  "lastUpdatedText": "Last Updated",
  "contributorsText": "Contributors",
  "notFound": [
    "There's nothing here.",
    "How did we get here?",
    "That's a Four-Oh-Four.",
    "Looks like we've got some broken links."
  ],
  "backToHome": "Take me home",
  "openInNewWindow": "open in new window",
  "toggleDarkMode": "toggle dark mode",
  "toggleSidebar": "toggle sidebar"
}
