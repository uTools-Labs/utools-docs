<template><h1 id="utools-api" tabindex="-1"><a class="header-anchor" href="#utools-api" aria-hidden="true">#</a> uTools API</h1>
<p>在插件应用初始化完成时，uTools 会自动在你的 window 对象上挂载 utools 对象。</p>
<h2 id="事件" tabindex="-1"><a class="header-anchor" href="#事件" aria-hidden="true">#</a> 事件</h2>
<p>你可以根据需要，事先定义好一些回调函数，uTools 会在事件产生时主动调用它们。</p>
<h3 id="onpluginenter-callback" tabindex="-1"><a class="header-anchor" href="#onpluginenter-callback" aria-hidden="true">#</a> <code>onPluginEnter(callback)</code></h3>
<ul>
<li><code>callback</code> Function
<ul>
<li><code>Object</code>
<ul>
<li>
<p><code>code</code> String</p>
<blockquote>
<p>plugin.json 配置的 feature.code</p>
</blockquote>
</li>
<li>
<p><code>type</code> String</p>
<blockquote>
<p>plugin.json 配置的 feature.cmd.type，可以为 &quot;text&quot;、&quot;img&quot;、 &quot;files&quot;、 &quot;regex&quot;、 &quot;over&quot;、&quot;window&quot;</p>
</blockquote>
</li>
<li>
<p><code>payload</code> String | Object | Array</p>
<blockquote>
<p>feature.cmd.type 对应匹配的数据</p>
</blockquote>
</li>
</ul>
</li>
</ul>
</li>
</ul>
<blockquote>
<p>进入插件应用时，uTools 将会主动调用这个方法。</p>
</blockquote>
<h4 id="示例" tabindex="-1"><a class="header-anchor" href="#示例" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">onPluginEnter</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter"><span class="token punctuation">{</span>code<span class="token punctuation">,</span> type<span class="token punctuation">,</span> payload<span class="token punctuation">}</span></span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'用户进入插件应用'</span><span class="token punctuation">,</span> code<span class="token punctuation">,</span> type<span class="token punctuation">,</span> payload<span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>

<span class="token comment">/* 
type 为 "files" 时， payload 值示例
[
	{
		"isFile": true,
		"isDirectory": false,
		"name": "demo.js",
		"path": "C:\\demo.js"
	}
]

type 为 "window" 时， payload 值示例
{
	"id": 264584,
	"class": "Chrome_WidgetWin_1",
	"title": "demo",
	"x": -8,
	"y": -8,
	"width": 1936,
	"height": 1056,
	"appPath": "C:\\demo.exe",
	"pid": 232,
	"app": "demo.exe"
}

type 为 "img" 时， payload 值示例
data:image/png;base64,...

type 为 "text"、"regex"、 "over" 时， payload 值为进入插件应用时的主输入框文本
*/</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br><span class="line-number">28</span><br><span class="line-number">29</span><br><span class="line-number">30</span><br><span class="line-number">31</span><br><span class="line-number">32</span><br><span class="line-number">33</span><br><span class="line-number">34</span><br></div></div><h3 id="onpluginout-callback" tabindex="-1"><a class="header-anchor" href="#onpluginout-callback" aria-hidden="true">#</a> <code>onPluginOut(callback)</code></h3>
<ul>
<li><code>callback</code> Function
<ul>
<li>
<p><code>processExit</code> Boolean</p>
<blockquote>
<p>是否完全退出插件应用</p>
</blockquote>
</li>
</ul>
</li>
</ul>
<blockquote>
<p>插件应用退出时，uTools 将会主动调用这个方法。</p>
</blockquote>
<h4 id="示例-1" tabindex="-1"><a class="header-anchor" href="#示例-1" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">onPluginOut</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter">processExit</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  <span class="token keyword">if</span> <span class="token punctuation">(</span>processExit<span class="token punctuation">)</span> <span class="token punctuation">{</span>
    console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'插件应用完全退出'</span><span class="token punctuation">)</span>
  <span class="token punctuation">}</span> <span class="token keyword">else</span> <span class="token punctuation">{</span>
    console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'插件应用隐藏后台'</span><span class="token punctuation">)</span>
  <span class="token punctuation">}</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br></div></div><h3 id="onplugindetach-callback" tabindex="-1"><a class="header-anchor" href="#onplugindetach-callback" aria-hidden="true">#</a> <code>onPluginDetach(callback)</code></h3>
<ul>
<li><code>callback</code> Function</li>
</ul>
<blockquote>
<p>用户对插件应用进行分离操作时，uTools 将会主动调用这个方法。</p>
</blockquote>
<h4 id="示例-2" tabindex="-1"><a class="header-anchor" href="#示例-2" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">onPluginDetach</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'插件应用已作为系统窗口使用'</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="ondbpull-callback" tabindex="-1"><a class="header-anchor" href="#ondbpull-callback" aria-hidden="true">#</a> <code>onDbPull(callback)</code></h3>
<ul>
<li><code>callback</code> Function</li>
</ul>
<blockquote>
<p>当此插件应用的数据在其他设备上被更改后同步到此设备时，uTools 将会主动调用这个方法</p>
</blockquote>
<h4 id="示例-3" tabindex="-1"><a class="header-anchor" href="#示例-3" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">onDbPull</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'onDbPull'</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h2 id="窗口交互" tabindex="-1"><a class="header-anchor" href="#窗口交互" aria-hidden="true">#</a> 窗口交互</h2>
<h3 id="hidemainwindow-isrestoreprewindow" tabindex="-1"><a class="header-anchor" href="#hidemainwindow-isrestoreprewindow" aria-hidden="true">#</a> <code>hideMainWindow(isRestorePreWindow)</code></h3>
<ul>
<li>
<p><code>isRestorePreWindow</code> Boolean</p>
<blockquote>
<p>是否焦点回归到前面的活动窗口，默认 true</p>
</blockquote>
</li>
<li>
<p><code>返回</code> Boolean</p>
</li>
</ul>
<blockquote>
<p>执行该方法将会隐藏 uTools 主窗口，包括此时正在主窗口运行的插件应用，分离的插件应用不会被隐藏。</p>
</blockquote>
<h4 id="示例-4" tabindex="-1"><a class="header-anchor" href="#示例-4" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">hideMainWindow</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="showmainwindow" tabindex="-1"><a class="header-anchor" href="#showmainwindow" aria-hidden="true">#</a> <code>showMainWindow()</code></h3>
<ul>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>执行该方法将会显示 uTools 主窗口，包括此时正在主窗口运行的插件应用。</p>
</blockquote>
<h4 id="示例-5" tabindex="-1"><a class="header-anchor" href="#示例-5" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">showMainWindow</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="setexpendheight-height" tabindex="-1"><a class="header-anchor" href="#setexpendheight-height" aria-hidden="true">#</a> <code>setExpendHeight(height)</code></h3>
<ul>
<li><code>height</code> Integer</li>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>执行该方法将会修改插件应用窗口的高度。</p>
</blockquote>
<h4 id="示例-6" tabindex="-1"><a class="header-anchor" href="#示例-6" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">setExpendHeight</span><span class="token punctuation">(</span><span class="token number">100</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="setsubinput-onchange-placeholder-isfocus" tabindex="-1"><a class="header-anchor" href="#setsubinput-onchange-placeholder-isfocus" aria-hidden="true">#</a> <code>setSubInput(onChange, placeholder, isFocus)</code></h3>
<ul>
<li>
<p><code>onChange</code> Function</p>
<ul>
<li><code>Object</code>
<ul>
<li><code>text</code> String</li>
</ul>
</li>
</ul>
<blockquote>
<p>子输入框文本修改时触发</p>
</blockquote>
</li>
<li>
<p><code>placeholder</code> String (可选)</p>
<blockquote>
<p>子输入框占位符</p>
</blockquote>
</li>
<li>
<p><code>isFocus</code> Boolean (可选)</p>
<blockquote>
<p>子输入框是否获得焦点，默认 true</p>
</blockquote>
</li>
<li>
<p><code>返回</code> Boolean</p>
</li>
</ul>
<blockquote>
<p>设置子输入框，进入插件应用后，原本 uTools 的搜索条主输入框将会变成子输入框，子输入框可以为插件应用所使用。</p>
</blockquote>
<p><img src="https://res.u-tools.cn/website/main.png" alt="main.png"></p>
<p align="center">主输入框</p>
<p><img src="https://res.u-tools.cn/website/subInput.png" alt="main.png"></p>
<p align="center">子输入框</p>
<h4 id="示例-7" tabindex="-1"><a class="header-anchor" href="#示例-7" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">setSubInput</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter"><span class="token punctuation">{</span> text <span class="token punctuation">}</span></span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>text<span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token string">'搜索'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="removesubinput" tabindex="-1"><a class="header-anchor" href="#removesubinput" aria-hidden="true">#</a> <code>removeSubInput()</code></h3>
<ul>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>移除已经设置的子输入框，在插件应用切换到其他页面时可以重新设置子输入框为其所用。</p>
</blockquote>
<h4 id="示例-8" tabindex="-1"><a class="header-anchor" href="#示例-8" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">removeSubInput</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="setsubinputvalue-value" tabindex="-1"><a class="header-anchor" href="#setsubinputvalue-value" aria-hidden="true">#</a> <code>setSubInputValue(value)</code></h3>
<ul>
<li><code>value</code> String</li>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>直接对子输入框的值进行设置。</p>
</blockquote>
<h4 id="示例-9" tabindex="-1"><a class="header-anchor" href="#示例-9" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">setSubInputValue</span><span class="token punctuation">(</span><span class="token string">'uTools'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="subinputfocus" tabindex="-1"><a class="header-anchor" href="#subinputfocus" aria-hidden="true">#</a> <code>subInputFocus()</code></h3>
<ul>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>子输入框获得焦点</p>
</blockquote>
<h4 id="示例-10" tabindex="-1"><a class="header-anchor" href="#示例-10" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">subInputFocus</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="subinputselect" tabindex="-1"><a class="header-anchor" href="#subinputselect" aria-hidden="true">#</a> <code>subInputSelect()</code></h3>
<ul>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>子输入框获得焦点并选中</p>
</blockquote>
<h4 id="示例-11" tabindex="-1"><a class="header-anchor" href="#示例-11" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">subInputSelect</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="subinputblur" tabindex="-1"><a class="header-anchor" href="#subinputblur" aria-hidden="true">#</a> <code>subInputBlur()</code></h3>
<ul>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>子输入框失去焦点，插件应用获得焦点</p>
</blockquote>
<h4 id="示例-12" tabindex="-1"><a class="header-anchor" href="#示例-12" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">subInputBlur</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="outplugin" tabindex="-1"><a class="header-anchor" href="#outplugin" aria-hidden="true">#</a> <code>outPlugin()</code></h3>
<ul>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>执行该方法将会退出当前插件应用。（插件应用进入后台，进程并未结束）</p>
</blockquote>
<h4 id="示例-13" tabindex="-1"><a class="header-anchor" href="#示例-13" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">outPlugin</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="redirect-label-payload" tabindex="-1"><a class="header-anchor" href="#redirect-label-payload" aria-hidden="true">#</a> <code>redirect(label, payload)</code></h3>
<ul>
<li>
<p><code>label</code> String</p>
<blockquote>
<p>feature.cmd.label 名称</p>
</blockquote>
</li>
<li>
<p><code>payload</code> String | Object</p>
<blockquote>
<p>feature.cmd.type 对应的数据</p>
</blockquote>
</li>
<li>
<p><code>返回</code> Boolean</p>
</li>
</ul>
<blockquote>
<p>该方法可以携带数据，跳转到另一个插件应用进行处理，如果用户未安装对应的插件应用，uTools 会弹出提醒并引导进入插件应用市场下载。</p>
</blockquote>
<h4 id="示例-14" tabindex="-1"><a class="header-anchor" href="#示例-14" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">//content 为string类型</span>
utools<span class="token punctuation">.</span><span class="token function">redirect</span><span class="token punctuation">(</span><span class="token string">'翻译'</span><span class="token punctuation">,</span> <span class="token string">'hello world'</span><span class="token punctuation">)</span>

<span class="token comment">//content 为object类型</span>
utools<span class="token punctuation">.</span><span class="token function">redirect</span><span class="token punctuation">(</span><span class="token string">'翻译'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
	<span class="token string-property property">'type'</span><span class="token operator">:</span> <span class="token string">'text'</span><span class="token punctuation">,</span>
	<span class="token string-property property">'data'</span><span class="token operator">:</span> <span class="token string">'hello world'</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>

<span class="token comment">//传递图片</span>
utools<span class="token punctuation">.</span><span class="token function">redirect</span><span class="token punctuation">(</span><span class="token string">'图片识别'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
	<span class="token string-property property">'type'</span><span class="token operator">:</span> <span class="token string">'img'</span><span class="token punctuation">,</span>
	<span class="token comment">// data 可以是本地图片路径、base64编码的图片、Buffer对象</span>
	<span class="token string-property property">'data'</span><span class="token operator">:</span> <span class="token string">'/path/to/img.jpg(支持jpeg|png|bmp)'</span> <span class="token comment">//filePath、base64、Buffer</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>

<span class="token comment">//传递文件、文件夹</span>
utools<span class="token punctuation">.</span><span class="token function">redirect</span><span class="token punctuation">(</span><span class="token string">'图片压缩'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
	<span class="token string-property property">'type'</span><span class="token operator">:</span> <span class="token string">'files'</span><span class="token punctuation">,</span>
	<span class="token comment">// data 可以是本地文件、文件夹路径</span>
	<span class="token string-property property">'data'</span><span class="token operator">:</span> <span class="token string">'/path/to/img.jpg'</span> <span class="token comment">//filePath、array</span>
	<span class="token comment">//'data': ['path1', 'path2'] //支持数组</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br></div></div><h3 id="showopendialog-options" tabindex="-1"><a class="header-anchor" href="#showopendialog-options" aria-hidden="true">#</a> <code>showOpenDialog(options)</code></h3>
<ul>
<li>
<p><code>options</code> Object</p>
<blockquote>
<p>与 <a href="https://www.electronjs.org/docs/api/dialog#dialogshowopendialogsyncbrowserwindow-options" target="_blank" rel="noopener noreferrer">Electron API dialog.showOpenDialogSync<ExternalLinkIcon/></a> options 一致</p>
</blockquote>
</li>
<li>
<p><code>返回</code> Array | undefined</p>
<blockquote>
<p>返回选择的文件数组，用户取消返回 undefined</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>弹出文件选择框</p>
</blockquote>
<h4 id="示例-15" tabindex="-1"><a class="header-anchor" href="#示例-15" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">showOpenDialog</span><span class="token punctuation">(</span><span class="token punctuation">{</span> 
  <span class="token literal-property property">filters</span><span class="token operator">:</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'name'</span><span class="token operator">:</span> <span class="token string">'plugin.json'</span><span class="token punctuation">,</span> <span class="token literal-property property">extensions</span><span class="token operator">:</span> <span class="token punctuation">[</span><span class="token string">'json'</span><span class="token punctuation">]</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> 
  <span class="token literal-property property">properties</span><span class="token operator">:</span> <span class="token punctuation">[</span><span class="token string">'openFile'</span><span class="token punctuation">]</span> 
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br></div></div><h3 id="showsavedialog-options" tabindex="-1"><a class="header-anchor" href="#showsavedialog-options" aria-hidden="true">#</a> <code>showSaveDialog(options)</code></h3>
<ul>
<li>
<p><code>options</code> Object</p>
<blockquote>
<p>与 <a href="https://www.electronjs.org/docs/api/dialog#dialogshowsavedialogsyncbrowserwindow-options" target="_blank" rel="noopener noreferrer">Electron API dialog.showSaveDialogSync<ExternalLinkIcon/></a> options 一致</p>
</blockquote>
</li>
<li>
<p><code>返回</code> String | undefined</p>
<blockquote>
<p>返回选择的路径，用户取消返回 undefined</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>弹出文件保存框</p>
</blockquote>
<h4 id="示例-16" tabindex="-1"><a class="header-anchor" href="#示例-16" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">showSaveDialog</span><span class="token punctuation">(</span><span class="token punctuation">{</span> 
  <span class="token literal-property property">title</span><span class="token operator">:</span> <span class="token string">'保存位置'</span><span class="token punctuation">,</span> 
  <span class="token literal-property property">defaultPath</span><span class="token operator">:</span> utools<span class="token punctuation">.</span><span class="token function">getPath</span><span class="token punctuation">(</span><span class="token string">'downloads'</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
  <span class="token literal-property property">buttonLabel</span><span class="token operator">:</span> <span class="token string">'保存'</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br></div></div><h3 id="findinpage-text-options" tabindex="-1"><a class="header-anchor" href="#findinpage-text-options" aria-hidden="true">#</a> <code>findInPage(text, options)</code></h3>
<ul>
<li>
<p><code>text</code> String</p>
<blockquote>
<p>要搜索的内容(必填)</p>
</blockquote>
</li>
<li>
<p><code>options</code> Object (可选)</p>
<blockquote>
<p>与 <a href="https://www.electronjs.org/docs/api/web-contents#contentsfindinpagetext-options" target="_blank" rel="noopener noreferrer">Electron API contentsfindinpagetext-options<ExternalLinkIcon/></a> options 一致</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>插件应用页面中查找内容</p>
</blockquote>
<h4 id="示例-17" tabindex="-1"><a class="header-anchor" href="#示例-17" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">findInPage</span><span class="token punctuation">(</span><span class="token string">'utools'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="stopfindinpage-action" tabindex="-1"><a class="header-anchor" href="#stopfindinpage-action" aria-hidden="true">#</a> <code>stopFindInPage(action)</code></h3>
<ul>
<li>
<p><code>action</code> String</p>
<blockquote>
<p>&quot;clearSelection&quot; | &quot;keepSelection&quot; | &quot;activateSelection&quot;, 默认 &quot;clearSelection&quot;</p>
<p>与 <a href="https://www.electronjs.org/docs/api/web-contents#contentsstopfindinpageaction" target="_blank" rel="noopener noreferrer">Electron API contentsstopfindinpageaction<ExternalLinkIcon/></a> 一致</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>停止插件应用页面中查找</p>
</blockquote>
<h4 id="示例-18" tabindex="-1"><a class="header-anchor" href="#示例-18" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">stopFindInPage</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="startdrag-file" tabindex="-1"><a class="header-anchor" href="#startdrag-file" aria-hidden="true">#</a> <code>startDrag(file)</code></h3>
<ul>
<li>
<p><code>file</code> String | Array</p>
<blockquote>
<p>文件路径 或 文件路径集合</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>原生拖拽文件到其他窗口</p>
</blockquote>
<h4 id="示例-19" tabindex="-1"><a class="header-anchor" href="#示例-19" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">startDrag</span><span class="token punctuation">(</span><span class="token string">'/path/to/file'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="createbrowserwindow-url-options-callback" tabindex="-1"><a class="header-anchor" href="#createbrowserwindow-url-options-callback" aria-hidden="true">#</a> <code>createBrowserWindow(url, options, callback)</code></h3>
<ul>
<li>
<p><code>url</code> String</p>
<blockquote>
<p>相对路径的 html 文件</p>
</blockquote>
</li>
<li>
<p><code>options</code> Object</p>
<blockquote>
<p>与 <a href="https://www.electronjs.org/docs/api/browser-window#new-browserwindowoptions" target="_blank" rel="noopener noreferrer">Electron API new BrowserWindow<ExternalLinkIcon/></a> 参数一样，注意：preload 需配置相对位置</p>
</blockquote>
</li>
<li>
<p><code>callback</code> Function (可选)</p>
<blockquote>
<p><code>url</code> 加载完成时回调</p>
</blockquote>
</li>
<li>
<p><code>返回</code> Object</p>
<blockquote>
<p>返回 uTools API 构建的 <a href="https://www.electronjs.org/docs/api/browser-window" target="_blank" rel="noopener noreferrer">BrowserWindow<ExternalLinkIcon/></a> 对象。 <em>保留了大部分实例方法</em></p>
</blockquote>
</li>
</ul>
<blockquote>
<p>创建浏览器窗口</p>
</blockquote>
<h4 id="示例-20" tabindex="-1"><a class="header-anchor" href="#示例-20" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">const</span> ubWindow <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">createBrowserWindow</span><span class="token punctuation">(</span><span class="token string">'test.html'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
  <span class="token literal-property property">show</span><span class="token operator">:</span> <span class="token boolean">false</span><span class="token punctuation">,</span>
  <span class="token literal-property property">title</span><span class="token operator">:</span> <span class="token string">'测试窗口'</span><span class="token punctuation">,</span>
  <span class="token literal-property property">webPreferences</span><span class="token operator">:</span> <span class="token punctuation">{</span>
    <span class="token literal-property property">preload</span><span class="token operator">:</span> <span class="token string">'preload.js'</span>
  <span class="token punctuation">}</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  <span class="token comment">// 显示</span>
  ubWindow<span class="token punctuation">.</span><span class="token function">show</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
  <span class="token comment">// 置顶</span>
  ubWindow<span class="token punctuation">.</span><span class="token function">setAlwaysOnTop</span><span class="token punctuation">(</span><span class="token boolean">true</span><span class="token punctuation">)</span>
  <span class="token comment">// 窗口全屏</span>
  ubWindow<span class="token punctuation">.</span><span class="token function">setFullScreen</span><span class="token punctuation">(</span><span class="token boolean">true</span><span class="token punctuation">)</span>
  <span class="token comment">// 向子窗口传递数据</span>
  ubWindow<span class="token punctuation">.</span>webContents<span class="token punctuation">.</span><span class="token function">send</span><span class="token punctuation">(</span><span class="token string">'ping'</span><span class="token punctuation">)</span>
  <span class="token function">require</span><span class="token punctuation">(</span><span class="token string">'electron'</span><span class="token punctuation">)</span><span class="token punctuation">.</span>ipcRenderer<span class="token punctuation">.</span><span class="token function">sendTo</span><span class="token punctuation">(</span>ubWindow<span class="token punctuation">.</span>webContents<span class="token punctuation">.</span>id<span class="token punctuation">,</span> <span class="token string">'ping'</span><span class="token punctuation">)</span>
  <span class="token comment">// 执行脚本</span>
  ubWindow<span class="token punctuation">.</span><span class="token function">executeJavaScript</span><span class="token punctuation">(</span><span class="token string">'fetch("https://jsonplaceholder.typicode.com/users/1").then(resp => resp.json())'</span><span class="token punctuation">)</span>
    <span class="token punctuation">.</span><span class="token function">then</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter">result</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
      console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>result<span class="token punctuation">)</span> <span class="token comment">// Will be the JSON object from the fetch call</span>
    <span class="token punctuation">}</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>ubWindow<span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br></div></div><div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 在新建窗口 JavaScript 中接收父窗口传递过来的数据</span>
<span class="token keyword">const</span> <span class="token punctuation">{</span> ipcRenderer <span class="token punctuation">}</span> <span class="token operator">=</span> <span class="token function">require</span><span class="token punctuation">(</span><span class="token string">'electron'</span><span class="token punctuation">)</span>
ipcRenderer<span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'ping'</span><span class="token punctuation">,</span> <span class="token punctuation">(</span><span class="token parameter">event<span class="token punctuation">,</span> data</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
    console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>event<span class="token punctuation">)</span><span class="token punctuation">;</span>
    console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>data<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br></div></div><h3 id="isdarkcolors" tabindex="-1"><a class="header-anchor" href="#isdarkcolors" aria-hidden="true">#</a> <code>isDarkColors()</code></h3>
<blockquote>
<p>是否深色模式</p>
</blockquote>
<h4 id="示例-21" tabindex="-1"><a class="header-anchor" href="#示例-21" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">onPluginEnter</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter"><span class="token punctuation">{</span>code<span class="token punctuation">,</span> type<span class="token punctuation">,</span> payload<span class="token punctuation">}</span></span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  document<span class="token punctuation">.</span>body<span class="token punctuation">.</span>className <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">isDarkColors</span><span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">?</span> <span class="token string">'dark-mode'</span> <span class="token operator">:</span> <span class="token string">''</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h2 id="动态增减功能" tabindex="-1"><a class="header-anchor" href="#动态增减功能" aria-hidden="true">#</a> 动态增减功能</h2>
<p>很多时候，插件应用中会提供一些功能供用户进行个性化设置（例如：<code>网页快开</code>插件应用），这部分配置无法在 <code>plugin.json</code> 事先定义好，所以我们提供了以下方法对插件应用功能进行动态增减。</p>
<h3 id="getfeatures-codes" tabindex="-1"><a class="header-anchor" href="#getfeatures-codes" aria-hidden="true">#</a> <code>getFeatures(codes)</code></h3>
<ul>
<li>
<p><code>codes</code> Array (可选)</p>
<blockquote>
<p>为空，获取所有</p>
</blockquote>
</li>
<li>
<p><code>返回</code> Array</p>
</li>
</ul>
<blockquote>
<p>获取插件应用动态创建的功能。</p>
</blockquote>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 获取所有动态功能</span>
<span class="token keyword">const</span> features <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getFeatures</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>features<span class="token punctuation">)</span>
<span class="token comment">// 获取特定 code</span>
<span class="token keyword">const</span> features <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getFeatures</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'code-1'</span><span class="token punctuation">,</span> <span class="token string">'code-2'</span><span class="token punctuation">]</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>features<span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br></div></div><h3 id="setfeature-feature" tabindex="-1"><a class="header-anchor" href="#setfeature-feature" aria-hidden="true">#</a> <code>setFeature(feature)</code></h3>
<ul>
<li>
<p><code>feature</code> Object</p>
<blockquote>
<p>格式与 <code>plugin.json</code> 中配置的格式一致</p>
</blockquote>
<ul>
<li><code>code</code> String</li>
<li><code>explain</code> String</li>
<li><code>icon</code> String (可选)</li>
<li><code>platform</code> Array (可选)</li>
<li><code>cmds</code> Array</li>
</ul>
</li>
<li>
<p><code>返回</code> Boolean</p>
</li>
</ul>
<blockquote>
<p>为本插件应用动态新增某个功能。</p>
</blockquote>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">setFeature</span><span class="token punctuation">(</span><span class="token punctuation">{</span>
  <span class="token string-property property">"code"</span><span class="token operator">:</span> <span class="token string">"hosts"</span><span class="token punctuation">,</span>
  <span class="token string-property property">"explain"</span><span class="token operator">:</span> <span class="token string">"hosts切换"</span><span class="token punctuation">,</span>
  <span class="token comment">// "icon": "res/xxx.png",</span>
  <span class="token comment">// "icon": "data:image/png;base64,xxx...",</span>
  <span class="token comment">// "platform": ["win32", "darwin", "linux"]</span>
  <span class="token string-property property">"cmds"</span><span class="token operator">:</span> <span class="token punctuation">[</span><span class="token string">"hosts"</span><span class="token punctuation">]</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br></div></div><h3 id="removefeature-code" tabindex="-1"><a class="header-anchor" href="#removefeature-code" aria-hidden="true">#</a> <code>removeFeature(code)</code></h3>
<ul>
<li><code>code</code> String</li>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>动态删除本插件应用的某个功能。</p>
</blockquote>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">removeFeature</span><span class="token punctuation">(</span><span class="token string">'code'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h2 id="用户" tabindex="-1"><a class="header-anchor" href="#用户" aria-hidden="true">#</a> 用户</h2>
<p>获取当前用户头像、昵称</p>
<h3 id="getuser" tabindex="-1"><a class="header-anchor" href="#getuser" aria-hidden="true">#</a> <code>getUser()</code></h3>
<ul>
<li>
<p><code>返回</code> Object</p>
<blockquote>
<p>{ avatar: String, nickname: String, type: 'member' | 'user' } | null</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取当前用户，未登录帐号返回 <code>null</code></p>
</blockquote>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>utools<span class="token punctuation">.</span><span class="token function">getUser</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="fetchuserservertemporarytoken" tabindex="-1"><a class="header-anchor" href="#fetchuserservertemporarytoken" aria-hidden="true">#</a> <code>fetchUserServerTemporaryToken()</code></h3>
<ul>
<li>
<p><code>返回</code> Promise</p>
<blockquote>
<p>Promise&lt;{ token: string, expired_at: number }&gt;</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取用户服务端临时令牌，用于<RouterLink to="/developer/server-api.html#%E8%8E%B7%E5%8F%96%E7%94%A8%E6%88%B7%E5%9F%BA%E7%A1%80%E4%BF%A1%E6%81%AF%E6%8E%A5%E5%8F%A3">获取用户基础信息接口</RouterLink></p>
</blockquote>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">fetchUserServerTemporaryToken</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">then</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter">ret</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>ret<span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h2 id="支付" tabindex="-1"><a class="header-anchor" href="#支付" aria-hidden="true">#</a> 支付</h2>
<h3 id="openpayment-options-callback" tabindex="-1"><a class="header-anchor" href="#openpayment-options-callback" aria-hidden="true">#</a> <code>openPayment(options, callback)</code></h3>
<ul>
<li>
<p><code>options</code></p>
<ul>
<li>
<p><code>goodsId</code> String</p>
<blockquote>
<p>商品 ID，在 “ uTools 开发者工具” 插件应用中创建</p>
</blockquote>
</li>
<li>
<p><code>outOrderId</code> String  (可选)</p>
<blockquote>
<p>第三方服务生成的订单号（6 - 64 字符）</p>
</blockquote>
</li>
<li>
<p><code>attach</code> String (可选)</p>
<blockquote>
<p>第三方服务附加数据，在查询API和支付通知中原样返回，可作为自定义参数使用（最多 256 字符）</p>
</blockquote>
</li>
</ul>
</li>
<li>
<p><code>callback</code></p>
<blockquote>
<p>支付成功后回调</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>打开支付</p>
</blockquote>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">openPayment</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token literal-property property">goodsId</span><span class="token operator">:</span> <span class="token string">'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  <span class="token comment">// 用户完成支付，继续业务代码</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="fetchuserpayments" tabindex="-1"><a class="header-anchor" href="#fetchuserpayments" aria-hidden="true">#</a> <code>fetchUserPayments()</code></h3>
<ul>
<li>
<p><code>返回</code> Promise</p>
<blockquote>
<p>Promise&lt;{ order_id: string, out_order_id: string, open_id:string,  pay_fee: number, body: string, attach: string, goods_id: string, paid_at: string,created_at }[]&gt;</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取用户支付记录</p>
</blockquote>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">fetchUserPayments</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">then</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter">ret</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  <span class="token comment">// 判断如果存在支付记录则继续相关业务</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>ret<span class="token punctuation">)</span><span class="token punctuation">;</span>
  <span class="token doc-comment comment">/**
  	    <span class="token punctuation">{</span>
        "order_id": "ZsVSwEDoR7PPs6vWdAGplEpEpNjn8xb4", // utools 订单号
        "out_order_id": "", // 外部订单号
        "open_id": "a331127d654761ac91d086b942aae7b6", uTools 用户 ID, 对于此插件应用不变且唯一
        "pay_fee": 1, // 支付金额（分）
        "body": "会员1年", // 支付内容
        "attach": "", // 附加数据
        "goods_id": "6n193s7P95p9gA13786YkwQ5oxHpVW4f", // 商品 ID
        "paid_at": "2021-06-18 16:55:26", // 支付时间
        "created_at": "2021-06-18 16:55:11" // 订单生成时间
    <span class="token punctuation">}</span>
  */</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br></div></div><h2 id="工具" tabindex="-1"><a class="header-anchor" href="#工具" aria-hidden="true">#</a> 工具</h2>
<p>屏幕取色 &amp; 屏幕截图</p>
<h3 id="screencolorpick-callback" tabindex="-1"><a class="header-anchor" href="#screencolorpick-callback" aria-hidden="true">#</a> <code>screenColorPick(callback)</code></h3>
<ul>
<li><code>callback</code> Function
<blockquote>
<p>取色结束回调</p>
</blockquote>
<ul>
<li><code>Object</code>
<ul>
<li><code>hex</code> String</li>
<li><code>rgb</code> String</li>
</ul>
</li>
</ul>
</li>
</ul>
<blockquote>
<p>屏幕取色</p>
</blockquote>
<h4 id="示例-22" tabindex="-1"><a class="header-anchor" href="#示例-22" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">screenColorPick</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter"><span class="token punctuation">{</span>hex<span class="token punctuation">,</span> rgb<span class="token punctuation">}</span></span><span class="token punctuation">)</span><span class="token operator">=></span><span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>hex<span class="token punctuation">)</span> <span class="token comment">// #FFFFFF</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>rgb<span class="token punctuation">)</span> <span class="token comment">// RGB(0, 0, 0)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br></div></div><h3 id="screencapture-callback" tabindex="-1"><a class="header-anchor" href="#screencapture-callback" aria-hidden="true">#</a> <code>screenCapture(callback)</code></h3>
<ul>
<li><code>callback</code> Function
<blockquote>
<p>截图结束回调</p>
</blockquote>
<ul>
<li>
<p><code>String</code></p>
<blockquote>
<p>图片的 Base64 字符串</p>
</blockquote>
</li>
</ul>
</li>
</ul>
<blockquote>
<p>屏幕截图</p>
</blockquote>
<h4 id="示例-23" tabindex="-1"><a class="header-anchor" href="#示例-23" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">screenCapture</span><span class="token punctuation">(</span><span class="token parameter">base64Str</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  utools<span class="token punctuation">.</span><span class="token function">redirect</span><span class="token punctuation">(</span><span class="token string">'识别图片中文字'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token literal-property property">type</span><span class="token operator">:</span> <span class="token string">'img'</span><span class="token punctuation">,</span> <span class="token literal-property property">data</span><span class="token operator">:</span> base64Str <span class="token punctuation">}</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="hidemainwindowtypestring-text" tabindex="-1"><a class="header-anchor" href="#hidemainwindowtypestring-text" aria-hidden="true">#</a> <code>hideMainWindowTypeString(text)</code></h3>
<ul>
<li>
<p><code>text</code> String</p>
<blockquote>
<p>任意文本包括 Emoji 符号字符</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>隐藏主窗口键盘输入字符串(输入法原理)，插件应用应用未分离下才能正常执行</p>
</blockquote>
<h4 id="示例-24" tabindex="-1"><a class="header-anchor" href="#示例-24" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 输入一句文本</span>
utools<span class="token punctuation">.</span><span class="token function">hideMainWindowTypeString</span><span class="token punctuation">(</span><span class="token string">'uTools 新一代效率工具平台 - 🐼👏🦄👨‍👩‍👧‍👦🚵🏻'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h2 id="模拟" tabindex="-1"><a class="header-anchor" href="#模拟" aria-hidden="true">#</a> 模拟</h2>
<p>模拟敲击键盘 和 鼠标点击</p>
<h3 id="simulatekeyboardtap-key-modifier" tabindex="-1"><a class="header-anchor" href="#simulatekeyboardtap-key-modifier" aria-hidden="true">#</a> <code>simulateKeyboardTap(key, ...modifier)</code></h3>
<ul>
<li>
<p><code>key</code> String</p>
<blockquote>
<p>键值</p>
</blockquote>
</li>
<li>
<p><code>modifier</code> String (可选)</p>
<blockquote>
<p>功能键</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>模拟键盘按键</p>
</blockquote>
<h4 id="示例-25" tabindex="-1"><a class="header-anchor" href="#示例-25" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 模拟键盘敲击 Enter</span>
utools<span class="token punctuation">.</span><span class="token function">simulateKeyboardTap</span><span class="token punctuation">(</span><span class="token string">'enter'</span><span class="token punctuation">)</span>
<span class="token comment">// windows linux 模拟粘贴</span>
utools<span class="token punctuation">.</span><span class="token function">simulateKeyboardTap</span><span class="token punctuation">(</span><span class="token string">'v'</span><span class="token punctuation">,</span> <span class="token string">'ctrl'</span><span class="token punctuation">)</span>
<span class="token comment">// macos 模拟粘贴</span>
utools<span class="token punctuation">.</span><span class="token function">simulateKeyboardTap</span><span class="token punctuation">(</span><span class="token string">'v'</span><span class="token punctuation">,</span> <span class="token string">'command'</span><span class="token punctuation">)</span>
<span class="token comment">// 模拟 Ctrl + Alt + A</span>
utools<span class="token punctuation">.</span><span class="token function">simulateKeyboardTap</span><span class="token punctuation">(</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'ctrl'</span><span class="token punctuation">,</span> <span class="token string">'alt'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br></div></div><h3 id="simulatemousemove-x-y" tabindex="-1"><a class="header-anchor" href="#simulatemousemove-x-y" aria-hidden="true">#</a> <code>simulateMouseMove(x, y)</code></h3>
<ul>
<li><code>x</code> Integer</li>
<li><code>y</code> Integer</li>
</ul>
<blockquote>
<p>模拟鼠标移动</p>
</blockquote>
<h4 id="示例-26" tabindex="-1"><a class="header-anchor" href="#示例-26" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">simulateMouseMove</span><span class="token punctuation">(</span><span class="token number">100</span>，<span class="token number">100</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="simulatemouseclick-x-y" tabindex="-1"><a class="header-anchor" href="#simulatemouseclick-x-y" aria-hidden="true">#</a> <code>simulateMouseClick(x, y)</code></h3>
<ul>
<li><code>x</code> Integer (可选)</li>
<li><code>y</code> Integer (可选)</li>
</ul>
<blockquote>
<p>模拟鼠标左键单击</p>
</blockquote>
<h4 id="示例-27" tabindex="-1"><a class="header-anchor" href="#示例-27" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">simulateMouseClick</span><span class="token punctuation">(</span><span class="token number">100</span>，<span class="token number">100</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="simulatemouserightclick-x-y" tabindex="-1"><a class="header-anchor" href="#simulatemouserightclick-x-y" aria-hidden="true">#</a> <code>simulateMouseRightClick(x, y)</code></h3>
<ul>
<li><code>x</code> Integer (可选)</li>
<li><code>y</code> Integer (可选)</li>
</ul>
<blockquote>
<p>模拟鼠标右键单击</p>
</blockquote>
<h4 id="示例-28" tabindex="-1"><a class="header-anchor" href="#示例-28" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">simulateMouseRightClick</span><span class="token punctuation">(</span><span class="token number">100</span>，<span class="token number">100</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="simulatemousedoubleclick-x-y" tabindex="-1"><a class="header-anchor" href="#simulatemousedoubleclick-x-y" aria-hidden="true">#</a> <code>simulateMouseDoubleClick(x, y)</code></h3>
<ul>
<li><code>x</code> Integer (可选)</li>
<li><code>y</code> Integer (可选)</li>
</ul>
<blockquote>
<p>模拟鼠标双击</p>
</blockquote>
<h4 id="示例-29" tabindex="-1"><a class="header-anchor" href="#示例-29" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">simulateMouseDoubleClick</span><span class="token punctuation">(</span><span class="token number">100</span>，<span class="token number">100</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h2 id="屏幕" tabindex="-1"><a class="header-anchor" href="#屏幕" aria-hidden="true">#</a> 屏幕</h2>
<h3 id="getcursorscreenpoint" tabindex="-1"><a class="header-anchor" href="#getcursorscreenpoint" aria-hidden="true">#</a> <code>getCursorScreenPoint()</code></h3>
<ul>
<li>
<p><code>返回</code> Object</p>
<blockquote>
<p>{ x: Integer, y: Integer }</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取鼠标绝对位置</p>
</blockquote>
<h4 id="示例-30" tabindex="-1"><a class="header-anchor" href="#示例-30" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">const</span> point <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getCursorScreenPoint</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>point<span class="token punctuation">.</span>x<span class="token punctuation">,</span> point<span class="token punctuation">.</span>y<span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="getprimarydisplay" tabindex="-1"><a class="header-anchor" href="#getprimarydisplay" aria-hidden="true">#</a> <code>getPrimaryDisplay()</code></h3>
<ul>
<li>
<p><code>返回</code> Object</p>
<blockquote>
<p><a href="https://www.electronjs.org/docs/api/structures/display" target="_blank" rel="noopener noreferrer">Display对象<ExternalLinkIcon/></a></p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取主显示器</p>
</blockquote>
<h4 id="示例-31" tabindex="-1"><a class="header-anchor" href="#示例-31" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">const</span> display <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getPrimaryDisplay</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>display<span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="getalldisplays" tabindex="-1"><a class="header-anchor" href="#getalldisplays" aria-hidden="true">#</a> <code>getAllDisplays()</code></h3>
<ul>
<li>
<p><code>返回</code> Array</p>
<blockquote>
<p><a href="https://www.electronjs.org/docs/api/structures/display" target="_blank" rel="noopener noreferrer">Display对象<ExternalLinkIcon/></a> 集合</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取所有显示器</p>
</blockquote>
<h4 id="示例-32" tabindex="-1"><a class="header-anchor" href="#示例-32" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">const</span> displays <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getAllDisplays</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>displays<span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="getdisplaynearestpoint-point" tabindex="-1"><a class="header-anchor" href="#getdisplaynearestpoint-point" aria-hidden="true">#</a> <code>getDisplayNearestPoint(point)</code></h3>
<ul>
<li>
<p><code>point</code> Object</p>
</li>
<li>
<p><code>返回</code> Object</p>
<blockquote>
<p><a href="https://www.electronjs.org/docs/api/structures/display" target="_blank" rel="noopener noreferrer">Display对象<ExternalLinkIcon/></a></p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取位置所在的显示器</p>
</blockquote>
<h4 id="示例-33" tabindex="-1"><a class="header-anchor" href="#示例-33" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">const</span> display <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getDisplayNearestPoint</span><span class="token punctuation">(</span><span class="token punctuation">{</span><span class="token literal-property property">x</span><span class="token operator">:</span> <span class="token number">100</span><span class="token punctuation">,</span> <span class="token literal-property property">y</span><span class="token operator">:</span> <span class="token number">100</span> <span class="token punctuation">}</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>display<span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="getdisplaymatching-rect" tabindex="-1"><a class="header-anchor" href="#getdisplaymatching-rect" aria-hidden="true">#</a> <code>getDisplayMatching(rect)</code></h3>
<ul>
<li>
<p><code>rect</code> Object</p>
</li>
<li>
<p><code>返回</code> Object</p>
<blockquote>
<p><a href="https://www.electronjs.org/docs/api/structures/display" target="_blank" rel="noopener noreferrer">Display对象<ExternalLinkIcon/></a></p>
</blockquote>
</li>
</ul>
<blockquote>
<p>获取矩形所在的显示器</p>
</blockquote>
<h4 id="示例-34" tabindex="-1"><a class="header-anchor" href="#示例-34" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">const</span> display <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getDisplayMatching</span><span class="token punctuation">(</span><span class="token punctuation">{</span><span class="token literal-property property">x</span><span class="token operator">:</span> <span class="token number">100</span><span class="token punctuation">,</span> <span class="token literal-property property">y</span><span class="token operator">:</span> <span class="token number">100</span><span class="token punctuation">,</span> <span class="token literal-property property">width</span><span class="token operator">:</span> <span class="token number">200</span><span class="token punctuation">,</span> <span class="token literal-property property">height</span><span class="token operator">:</span> <span class="token number">200</span> <span class="token punctuation">}</span><span class="token punctuation">)</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>display<span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="desktopcapturesources-options" tabindex="-1"><a class="header-anchor" href="#desktopcapturesources-options" aria-hidden="true">#</a> <code>desktopCaptureSources(options)</code></h3>
<ul>
<li><code>options</code> Object</li>
<li><code>返回</code> Promise</li>
</ul>
<blockquote>
<p>录屏源 <a href="https://www.electronjs.org/zh/docs/latest/api/desktop-capturer" target="_blank" rel="noopener noreferrer">参考 Electron API desktopCapturer getSources<ExternalLinkIcon/></a></p>
</blockquote>
<h4 id="示例-35" tabindex="-1"><a class="header-anchor" href="#示例-35" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token punctuation">(</span><span class="token keyword">async</span> <span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  <span class="token keyword">const</span> ousrces <span class="token operator">=</span> <span class="token keyword">await</span> utools<span class="token punctuation">.</span><span class="token function">desktopCaptureSources</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token literal-property property">types</span><span class="token operator">:</span> <span class="token punctuation">[</span><span class="token string">'window'</span><span class="token punctuation">,</span> <span class="token string">'screen'</span><span class="token punctuation">]</span> <span class="token punctuation">}</span><span class="token punctuation">)</span>
  <span class="token keyword">const</span> stream <span class="token operator">=</span> <span class="token keyword">await</span> navigator<span class="token punctuation">.</span>mediaDevices<span class="token punctuation">.</span><span class="token function">getUserMedia</span><span class="token punctuation">(</span><span class="token punctuation">{</span>
    <span class="token literal-property property">audio</span><span class="token operator">:</span> <span class="token boolean">false</span><span class="token punctuation">,</span>
    <span class="token literal-property property">video</span><span class="token operator">:</span> <span class="token punctuation">{</span>
      <span class="token literal-property property">mandatory</span><span class="token operator">:</span> <span class="token punctuation">{</span>
        <span class="token literal-property property">chromeMediaSource</span><span class="token operator">:</span> <span class="token string">'desktop'</span><span class="token punctuation">,</span>
        <span class="token literal-property property">chromeMediaSourceId</span><span class="token operator">:</span> ousrces<span class="token punctuation">[</span><span class="token number">0</span><span class="token punctuation">]</span><span class="token punctuation">.</span>id<span class="token punctuation">,</span>
        <span class="token literal-property property">minWidth</span><span class="token operator">:</span> <span class="token number">1280</span><span class="token punctuation">,</span>
        <span class="token literal-property property">maxWidth</span><span class="token operator">:</span> <span class="token number">1280</span><span class="token punctuation">,</span>
        <span class="token literal-property property">minHeight</span><span class="token operator">:</span> <span class="token number">720</span><span class="token punctuation">,</span>
        <span class="token literal-property property">maxHeight</span><span class="token operator">:</span> <span class="token number">720</span>
      <span class="token punctuation">}</span>
    <span class="token punctuation">}</span>
  <span class="token punctuation">}</span><span class="token punctuation">)</span>
  <span class="token keyword">const</span> video <span class="token operator">=</span> document<span class="token punctuation">.</span><span class="token function">querySelector</span><span class="token punctuation">(</span><span class="token string">'video'</span><span class="token punctuation">)</span>
  video<span class="token punctuation">.</span>srcObject <span class="token operator">=</span> stream
  video<span class="token punctuation">.</span><span class="token function-variable function">onloadedmetadata</span> <span class="token operator">=</span> <span class="token punctuation">(</span><span class="token parameter">e</span><span class="token punctuation">)</span> <span class="token operator">=></span> video<span class="token punctuation">.</span><span class="token function">play</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br></div></div><h2 id="复制" tabindex="-1"><a class="header-anchor" href="#复制" aria-hidden="true">#</a> 复制</h2>
<h3 id="copyfile-file" tabindex="-1"><a class="header-anchor" href="#copyfile-file" aria-hidden="true">#</a> <code>copyFile(file)</code></h3>
<ul>
<li><code>file</code> String | Array</li>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>复制文件到系统剪贴板</p>
</blockquote>
<h4 id="示例-36" tabindex="-1"><a class="header-anchor" href="#示例-36" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 复制单个文件</span>
utools<span class="token punctuation">.</span><span class="token function">copyFile</span><span class="token punctuation">(</span><span class="token string">'/path/to/file'</span><span class="token punctuation">)</span>
<span class="token comment">// 复制多个文件</span>
utools<span class="token punctuation">.</span><span class="token function">copyFile</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'/path/to/file1'</span><span class="token punctuation">,</span> <span class="token string">'/path/to/file2'</span><span class="token punctuation">]</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br></div></div><h3 id="copyimage-img" tabindex="-1"><a class="header-anchor" href="#copyimage-img" aria-hidden="true">#</a> <code>copyImage(img)</code></h3>
<ul>
<li><code>img</code> String | Buffer</li>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>复制图片到系统剪贴板</p>
</blockquote>
<h4 id="示例-37" tabindex="-1"><a class="header-anchor" href="#示例-37" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 路径</span>
utools<span class="token punctuation">.</span><span class="token function">copyImage</span><span class="token punctuation">(</span><span class="token string">'/path/to/img.png'</span><span class="token punctuation">)</span>
<span class="token comment">// base64</span>
utools<span class="token punctuation">.</span><span class="token function">copyImage</span><span class="token punctuation">(</span><span class="token string">'data:image/png;base64,xxxxxxxxx'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br></div></div><h3 id="copytext-text" tabindex="-1"><a class="header-anchor" href="#copytext-text" aria-hidden="true">#</a> <code>copyText(text)</code></h3>
<ul>
<li><code>text</code> String</li>
<li><code>返回</code> Boolean</li>
</ul>
<blockquote>
<p>复制文本</p>
</blockquote>
<h4 id="示例-38" tabindex="-1"><a class="header-anchor" href="#示例-38" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">copyText</span><span class="token punctuation">(</span><span class="token string">'Hi, uTools'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="getcopyedfiles" tabindex="-1"><a class="header-anchor" href="#getcopyedfiles" aria-hidden="true">#</a> <code>getCopyedFiles()</code></h3>
<ul>
<li><code>返回</code> Array</li>
</ul>
<blockquote>
<p>获取复制的文件或文件夹</p>
</blockquote>
<h4 id="示例-39" tabindex="-1"><a class="header-anchor" href="#示例-39" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">getCopyedFiles</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
<span class="token comment">// 返回 [{ isFile: true, isDirectory: false, name: 'test.png', path: '/path/to/test.png' }]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h2 id="系统" tabindex="-1"><a class="header-anchor" href="#系统" aria-hidden="true">#</a> 系统</h2>
<h3 id="shownotification-body-clickfeaturecode" tabindex="-1"><a class="header-anchor" href="#shownotification-body-clickfeaturecode" aria-hidden="true">#</a> <code>showNotification(body, clickFeatureCode)</code></h3>
<ul>
<li>
<p><code>body</code> String</p>
</li>
<li>
<p><code>clickFeatureCode</code> String (可选)</p>
<blockquote>
<p>plugin.json 配置的 feature.code，点击通知进入插件应用功能(该 feature.cmds 至少包含一个搜索字符串关键字)</p>
</blockquote>
</li>
</ul>
<blockquote>
<p>显示系统通知</p>
</blockquote>
<h4 id="示例-40" tabindex="-1"><a class="header-anchor" href="#示例-40" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">showNotification</span><span class="token punctuation">(</span><span class="token string">'Hi, uTools'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="shellopenpath-fullpath" tabindex="-1"><a class="header-anchor" href="#shellopenpath-fullpath" aria-hidden="true">#</a> <code>shellOpenPath(fullPath)</code></h3>
<ul>
<li><code>fullPath</code> String</li>
</ul>
<blockquote>
<p>系统默认方式打开给定的文件</p>
</blockquote>
<h4 id="示例-41" tabindex="-1"><a class="header-anchor" href="#示例-41" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">shellOpenPath</span><span class="token punctuation">(</span><span class="token string">'/path/to/file'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="shellshowiteminfolder-fullpath" tabindex="-1"><a class="header-anchor" href="#shellshowiteminfolder-fullpath" aria-hidden="true">#</a> <code>shellShowItemInFolder(fullPath)</code></h3>
<ul>
<li><code>fullPath</code> String</li>
</ul>
<blockquote>
<p>系统文件管理器中显示给定的文件</p>
</blockquote>
<h4 id="示例-42" tabindex="-1"><a class="header-anchor" href="#示例-42" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">shellShowItemInFolder</span><span class="token punctuation">(</span><span class="token string">'/path/to/file'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="shellopenexternal-url" tabindex="-1"><a class="header-anchor" href="#shellopenexternal-url" aria-hidden="true">#</a> <code>shellOpenExternal(url)</code></h3>
<ul>
<li><code>url</code> String</li>
</ul>
<blockquote>
<p>系统默认的协议打开URL</p>
</blockquote>
<h4 id="示例-43" tabindex="-1"><a class="header-anchor" href="#示例-43" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 浏览器打开</span>
utools<span class="token punctuation">.</span><span class="token function">shellOpenExternal</span><span class="token punctuation">(</span><span class="token string">'https://u.tools'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="shellbeep" tabindex="-1"><a class="header-anchor" href="#shellbeep" aria-hidden="true">#</a> <code>shellBeep()</code></h3>
<blockquote>
<p>播放哔哔声</p>
</blockquote>
<h4 id="示例-44" tabindex="-1"><a class="header-anchor" href="#示例-44" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">shellBeep</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="getnativeid" tabindex="-1"><a class="header-anchor" href="#getnativeid" aria-hidden="true">#</a> <code>getNativeId()</code></h3>
<ul>
<li><code>返回</code> String</li>
</ul>
<blockquote>
<p>获取本地 ID</p>
</blockquote>
<h4 id="示例-45" tabindex="-1"><a class="header-anchor" href="#示例-45" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 存储只与当前设备相关的信息</span>
<span class="token keyword">const</span> nativeId <span class="token operator">=</span> utools<span class="token punctuation">.</span><span class="token function">getNativeId</span><span class="token punctuation">(</span><span class="token punctuation">)</span>
utools<span class="token punctuation">.</span>dbStorage<span class="token punctuation">.</span><span class="token function">setItem</span><span class="token punctuation">(</span>nativeId <span class="token operator">+</span> <span class="token string">'/key'</span><span class="token punctuation">,</span> <span class="token string">'native value'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="getappversion" tabindex="-1"><a class="header-anchor" href="#getappversion" aria-hidden="true">#</a> <code>getAppVersion()</code></h3>
<ul>
<li><code>返回</code> String</li>
</ul>
<blockquote>
<p>获取软件版本</p>
</blockquote>
<h4 id="示例-46" tabindex="-1"><a class="header-anchor" href="#示例-46" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>utools<span class="token punctuation">.</span><span class="token function">getAppVersion</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br></div></div><h3 id="getpath-name" tabindex="-1"><a class="header-anchor" href="#getpath-name" aria-hidden="true">#</a> <code>getPath(name)</code></h3>
<ul>
<li><code>name</code> String
<blockquote>
<p>你可以通过名称请求以下的路径:</p>
</blockquote>
<ul>
<li><code>home</code> 用户的 home 文件夹（主目录）</li>
<li><code>appData</code> 当前用户的应用数据文件夹，默认对应：
<ul>
<li><code>%APPDATA%</code> Windows 中</li>
<li><code>~/Library/Application Support</code> macOS 中</li>
</ul>
</li>
<li><code>userData</code> 储存你应用程序设置文件的文件夹，默认是 appData 文件夹附加应用的名称</li>
<li><code>temp</code> 临时文件夹</li>
<li><code>exe</code> 当前的可执行文件</li>
<li><code>desktop</code> 当前用户的桌面文件夹</li>
<li><code>documents</code> 用户文档目录的路径</li>
<li><code>downloads</code> 用户下载目录的路径</li>
<li><code>music</code> 用户音乐目录的路径</li>
<li><code>pictures</code> 用户图片目录的路径</li>
<li><code>videos</code> 用户视频目录的路径</li>
<li><code>logs</code> 应用程序的日志文件夹</li>
</ul>
</li>
<li><code>返回</code> String</li>
</ul>
<blockquote>
<p>获取路径</p>
</blockquote>
<h4 id="示例-47" tabindex="-1"><a class="header-anchor" href="#示例-47" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 获取下载路径</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>utools<span class="token punctuation">.</span><span class="token function">getPath</span><span class="token punctuation">(</span><span class="token string">'downloads'</span><span class="token punctuation">)</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="getfileicon-filepath" tabindex="-1"><a class="header-anchor" href="#getfileicon-filepath" aria-hidden="true">#</a> <code>getFileIcon(filePath)</code></h3>
<ul>
<li>
<p><code>filePath</code> String</p>
<blockquote>
<p>文件路径、文件扩展名、&quot;folder&quot;</p>
</blockquote>
</li>
<li>
<p><code>返回</code> String</p>
</li>
</ul>
<blockquote>
<p>获取文件图标</p>
</blockquote>
<h4 id="示例-48" tabindex="-1"><a class="header-anchor" href="#示例-48" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token comment">// 获取扩展名为 "txt" 的文件图标</span>
utools<span class="token punctuation">.</span><span class="token function">getFileIcon</span><span class="token punctuation">(</span><span class="token string">'.txt'</span><span class="token punctuation">)</span>
<span class="token comment">// 获取文件夹图标</span>
utools<span class="token punctuation">.</span><span class="token function">getFileIcon</span><span class="token punctuation">(</span><span class="token string">'folder'</span><span class="token punctuation">)</span>
<span class="token comment">// 获取文件图标</span>
utools<span class="token punctuation">.</span><span class="token function">getFileIcon</span><span class="token punctuation">(</span><span class="token string">'D:\\test.url'</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br></div></div><h3 id="readcurrentfolderpath" tabindex="-1"><a class="header-anchor" href="#readcurrentfolderpath" aria-hidden="true">#</a> <code>readCurrentFolderPath()</code></h3>
<ul>
<li><code>返回</code> Promise</li>
</ul>
<blockquote>
<p>读取当前文件管理器窗口路径 (linux 不支持)</p>
</blockquote>
<h4 id="示例-49" tabindex="-1"><a class="header-anchor" href="#示例-49" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">readCurrentFolderPath</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">then</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter">dir</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>dir<span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="readcurrentbrowserurl" tabindex="-1"><a class="header-anchor" href="#readcurrentbrowserurl" aria-hidden="true">#</a> <code>readCurrentBrowserUrl()</code></h3>
<ul>
<li><code>返回</code> Promise</li>
</ul>
<blockquote>
<p>读取当前浏览器窗口 URL (linux 不支持)</p>
</blockquote>
<blockquote>
<p>MacOS 支持浏览器 Safari、Chrome、Microsoft Edge、Opera、Vivaldi、Brave</p>
</blockquote>
<blockquote>
<p>Windows 支持浏览器 Chrome、Firefox、Edge、IE、Opera、Brave</p>
</blockquote>
<h4 id="示例-50" tabindex="-1"><a class="header-anchor" href="#示例-50" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code>utools<span class="token punctuation">.</span><span class="token function">readCurrentBrowserUrl</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">then</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter">url</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>url<span class="token punctuation">)</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="isdev" tabindex="-1"><a class="header-anchor" href="#isdev" aria-hidden="true">#</a> <code>isDev()</code></h3>
<blockquote>
<p>判断插件应用是否在开发环境</p>
</blockquote>
<h4 id="示例-51" tabindex="-1"><a class="header-anchor" href="#示例-51" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">if</span> <span class="token punctuation">(</span>utools<span class="token punctuation">.</span><span class="token function">isDev</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'coding'</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="ismacos" tabindex="-1"><a class="header-anchor" href="#ismacos" aria-hidden="true">#</a> <code>isMacOS()</code></h3>
<blockquote>
<p>是否 MacOS 操作系统</p>
</blockquote>
<h4 id="示例-52" tabindex="-1"><a class="header-anchor" href="#示例-52" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">if</span> <span class="token punctuation">(</span>utools<span class="token punctuation">.</span><span class="token function">isMacOS</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'mac'</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="iswindows" tabindex="-1"><a class="header-anchor" href="#iswindows" aria-hidden="true">#</a> <code>isWindows()</code></h3>
<blockquote>
<p>是否 Windows 操作系统</p>
</blockquote>
<h4 id="示例-53" tabindex="-1"><a class="header-anchor" href="#示例-53" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">if</span> <span class="token punctuation">(</span>utools<span class="token punctuation">.</span><span class="token function">isWindows</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'windows'</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h3 id="islinux" tabindex="-1"><a class="header-anchor" href="#islinux" aria-hidden="true">#</a> <code>isLinux()</code></h3>
<blockquote>
<p>是否 Linux 操作系统</p>
</blockquote>
<h4 id="示例-54" tabindex="-1"><a class="header-anchor" href="#示例-54" aria-hidden="true">#</a> 示例</h4>
<div class="language-javascript ext-js line-numbers-mode"><pre v-pre class="language-javascript"><code><span class="token keyword">if</span> <span class="token punctuation">(</span>utools<span class="token punctuation">.</span><span class="token function">isLinux</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'linux'</span><span class="token punctuation">)</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div></template>
