export const data = {
  "key": "v-0eda91d6",
  "path": "/developer/welcome.html",
  "title": "快速上手",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "plugin.json",
      "slug": "plugin-json",
      "children": []
    },
    {
      "level": 2,
      "title": "开发者中心",
      "slug": "开发者中心",
      "children": []
    }
  ],
  "filePathRelative": "developer/welcome.md"
}
