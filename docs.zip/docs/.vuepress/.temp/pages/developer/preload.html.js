export const data = {
  "key": "v-5e3a74ce",
  "path": "/developer/preload.html",
  "title": "preload.js",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "developer/preload.md"
}
