export const data = {
  "key": "v-3d82b21e",
  "path": "/developer/payment.html",
  "title": "插件内收款服务",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "developer/payment.md"
}
