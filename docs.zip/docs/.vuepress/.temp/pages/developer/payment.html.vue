<template><h1 id="插件内收款服务" tabindex="-1"><a class="header-anchor" href="#插件内收款服务" aria-hidden="true">#</a> 插件内收款服务</h1>
<p>uTools 为插件开发者提供收款能力，你可以给插件功能或增值服务定价，并使用 uTools 提供的<RouterLink to="/developer/api.html#%E6%94%AF%E4%BB%98">支付 api</RouterLink> 来完成收款。</p>
<h4 id="如何申请" tabindex="-1"><a class="header-anchor" href="#如何申请" aria-hidden="true">#</a> 如何申请</h4>
<ol>
<li>企业开发者可以在开发者工具中直接提交申请</li>
<li>个人开发者将以下信息发邮件到 <code>service@u.tools</code> 申请支付权限</li>
</ol>
<p>邮件标题为：申请 uTools 插件支付权限</p>
<p>邮件中提供的资料：</p>
<p>姓名、身份证正反面、手机号码、插件名称及插件ID、描述收款用途、结算银行及卡号（详细到开户行）</p>
<p>我们会在 3 个工作日内处理</p>
<h4 id="服务费率" tabindex="-1"><a class="header-anchor" href="#服务费率" aria-hidden="true">#</a> 服务费率</h4>
<p>uTools 将收取收款金额的 15% 作为服务费，用于第三方支付通道费率、银行转账手续费、uTools 会员折扣等（当 uTools 会员购买您的服务时，由我们从收取的服务费中统一给会员用户 9 折优惠）</p>
<h4 id="如何结算" tabindex="-1"><a class="header-anchor" href="#如何结算" aria-hidden="true">#</a> 如何结算</h4>
<ol>
<li>待结算的金额需至少到达 100 元</li>
<li>你的插件获取的收益，将在扣除服务费后，于每月 10 号统一支付上一月的收益到你的结算银行卡中</li>
</ol>
<h4 id="注意" tabindex="-1"><a class="header-anchor" href="#注意" aria-hidden="true">#</a> 注意</h4>
<p>请审慎阅读并同意 <a href="/dev.html" target="_blank" rel="noopener noreferrer">《uTools 开发者协议》<ExternalLinkIcon/></a>，并基于此协议为用户提供优质的插件及服务。</p>
</template>
