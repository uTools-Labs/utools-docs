export const data = {
  "key": "v-4f98fc52",
  "path": "/developer/best.html",
  "title": "注意事项",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "developer/best.md"
}
