export const data = {
  "key": "v-7e757cd5",
  "path": "/terms_dev.html",
  "title": "uTools 开发者协议",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "terms_dev.md"
}
