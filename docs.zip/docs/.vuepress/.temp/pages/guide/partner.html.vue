<template><p>partner</p>
</template>
