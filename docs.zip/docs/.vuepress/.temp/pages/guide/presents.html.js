export const data = {
  "key": "v-1b001156",
  "path": "/guide/presents.html",
  "title": "",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "guide/presents.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
