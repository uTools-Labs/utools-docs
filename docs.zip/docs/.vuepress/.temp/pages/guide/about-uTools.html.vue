<template><h1 id="介绍" tabindex="-1"><a class="header-anchor" href="#介绍" aria-hidden="true">#</a> 介绍</h1>
<p><img src="https://res.u-tools.cn/website/utools.png" alt="utools.png"></p>
<h2 id="utools-是什么" tabindex="-1"><a class="header-anchor" href="#utools-是什么" aria-hidden="true">#</a> uTools 是什么？</h2>
<blockquote>
<p>uTools = your tools（你的工具集）</p>
</blockquote>
<p>uTools 是一个极简、插件化的现代桌面软件，通过自由选配丰富的插件，打造得心应手的工具集合。</p>
<p>通过快捷键（默认 <code>alt + space</code> ）就可以快速呼出这个搜索框。你可以往输入框内粘贴文本、图片、截图、文件、文件夹等等，能够处理此内容的插件也早已准备就绪，统一的设计风格和操作方式，助你高效的得到结果。</p>
<img src="https://res.u-tools.cn/images/uTools_1675654844513.png" style="zoom:50%;" />
<p>一旦你熟悉它后，能够为你节约大量时间，即用即走、不中断、无干扰，让你可以更加专注地改变世界。</p>
<blockquote>
<p>观看 uTools 的介绍视频</p>
</blockquote>
<p><a href="https://www.bilibili.com/video/BV1g24y1X77N?share_source=copy_web" target="_blank" rel="noopener noreferrer"><img src="https://res.u-tools.cn/images/play.png" alt="dd"><ExternalLinkIcon/></a></p>
<h2 id="utools-能做什么" tabindex="-1"><a class="header-anchor" href="#utools-能做什么" aria-hidden="true">#</a> uTools 能做什么？</h2>
<p>最简单的，uTools 可以作为一个程序快速启动器，支持英文、英文驼峰、中文拼音、拼音首字母来打开你的本地程序。除程序外， win10+ 和 MacOS 用户还可以快速搜索并打开「控制面板」内的细项。总之，你只要还记得一个大概的名字，直接输入基本都能找到。</p>
<h2 id="一切皆插件" tabindex="-1"><a class="header-anchor" href="#一切皆插件" aria-hidden="true">#</a> 一切皆插件！</h2>
<p>启动已安装的程序仅仅是最基础的功能，uTools 最大的特点就是拥有强大的插件系统。</p>
<p>现在已有 700+ 的插件供你选择，每个插件解决一个具体场景的问题，简洁美观、即用即走。</p>
<p>输入 <code>插件应用市场</code> 进入插件管理，你就可以根据自己的需求挑选安装，组合成自己最称手的工具集合，为各种日常操作提供便利，不断产生的新插件，将为你带来无限可能。</p>
<img src="https://res.u-tools.cn/website/plugin1.png" alt="plugin" style="zoom:50%;" />
<h2 id="超级面板" tabindex="-1"><a class="header-anchor" href="#超级面板" aria-hidden="true">#</a> 超级面板</h2>
<p>可以通过鼠标右键/中键（可配置），快速打开 uTools 超级面板，uTools 会根据当前选择的内容（文本、截图、文件、文件夹）自动匹配已安装的插件供你选择。与平时使用右键类似的习惯，uTools 超级面板却能为你带来完全不一样的内容及体验。</p>
<blockquote>
<p>针对英文，还提供单词词典和整句翻译功能。</p>
</blockquote>
<img src="https://res.u-tools.cn/website/translate.jpg" alt="superPanel" style="zoom:50%;" />
<h2 id="utools-和-「猿料」-是什么关系" tabindex="-1"><a class="header-anchor" href="#utools-和-「猿料」-是什么关系" aria-hidden="true">#</a> uTools 和 「猿料」 是什么关系？</h2>
<p>uTools 一开始叫做猿料，意思是：程序员需要的材料/工具。</p>
<p>当我们开始为猿料寻找域名时，无意间发现了 u.tools ，感觉和我们想做的产品内容、域名、寓意都完美融合，遂改名叫 uTools 。对猿料这个名字依然喜爱，现在作为我们反馈社区的名称。</p>
<blockquote>
<p><a href="https://mp.weixin.qq.com/s/fleBqpkv3w3q_mIBA05XCg" target="_blank" rel="noopener noreferrer">开发者说 | 为什么开发 uTools ?<ExternalLinkIcon/></a></p>
</blockquote>
<h2 id="联系方式" tabindex="-1"><a class="header-anchor" href="#联系方式" aria-hidden="true">#</a> 联系方式</h2>
<p>猿料社区：<a href="https://yuanliao.info" target="_blank" rel="noopener noreferrer">https://yuanliao.info<ExternalLinkIcon/></a></p>
<blockquote>
<p>任何 bug 、建议、想法，欢迎在社区发布，以便我们有针对性的回复及整理</p>
</blockquote>
<p>邮箱：<a href="mailto:service@u.tools">service@u.tools</a></p>
<p>微信群 (群人数限制，将邀请你加入群聊)：</p>
<img src="https://res.u-tools.cn/upload/qr-utools.jpg" alt="dev" style="zoom:50%;" />
<p>欢迎关注「猿料」公众号（插件推荐、开发故事）：</p>
<p><img src="https://res.u-tools.cn/plugins/upload/qrcode_for_gh_91815b1958c7_258.jpg" alt="dev"></p>
</template>
