export const data = {
  "key": "v-e4f906f2",
  "path": "/guide/about-uTools.html",
  "title": "介绍",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "uTools 是什么？",
      "slug": "utools-是什么",
      "children": []
    },
    {
      "level": 2,
      "title": "uTools 能做什么？",
      "slug": "utools-能做什么",
      "children": []
    },
    {
      "level": 2,
      "title": "一切皆插件！",
      "slug": "一切皆插件",
      "children": []
    },
    {
      "level": 2,
      "title": "超级面板",
      "slug": "超级面板",
      "children": []
    },
    {
      "level": 2,
      "title": "uTools 和 「猿料」 是什么关系？",
      "slug": "utools-和-「猿料」-是什么关系",
      "children": []
    },
    {
      "level": 2,
      "title": "联系方式",
      "slug": "联系方式",
      "children": []
    }
  ],
  "filePathRelative": "guide/about-uTools.md"
}
