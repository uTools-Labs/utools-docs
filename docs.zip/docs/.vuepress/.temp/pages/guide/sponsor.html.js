export const data = {
  "key": "v-9edff62a",
  "path": "/guide/sponsor.html",
  "title": "如何与我们合作？",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 3,
      "title": "活动赞助",
      "slug": "活动赞助",
      "children": []
    },
    {
      "level": 3,
      "title": "商业合作",
      "slug": "商业合作",
      "children": []
    }
  ],
  "filePathRelative": "guide/sponsor.md"
}
