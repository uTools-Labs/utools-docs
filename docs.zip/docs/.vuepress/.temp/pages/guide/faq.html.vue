<template><h1 id="常见问题" tabindex="-1"><a class="header-anchor" href="#常见问题" aria-hidden="true">#</a> 常见问题</h1>
<p>本文档收集了部分用户在使用 uTools 过程中遇到的问题，如果这里没有你遇到的问题，可以在 uTools 官方论坛里发帖寻求帮助。</p>
<h3 id="安装时遇到了「无法打开-utools-因为-apple-无法检查是否包含恶意软体」的情况怎么办" tabindex="-1"><a class="header-anchor" href="#安装时遇到了「无法打开-utools-因为-apple-无法检查是否包含恶意软体」的情况怎么办" aria-hidden="true">#</a> 安装时遇到了「无法打开 uTools，因为 Apple 无法检查是否包含恶意软体」的情况怎么办？<Badge text="macOS"/></h3>
<p>依次打开「系统偏好设置」→「安全性与隐私」→「通用」，在页面底部选择「仍要安装」即可。</p>
<h3 id="utools-会收费吗" tabindex="-1"><a class="header-anchor" href="#utools-会收费吗" aria-hidden="true">#</a> uTools 会收费吗？</h3>
<p>uTools 目前采用会员付费制，基础功能永久免费使用，增值服务收费。会员用户可以享受包括「数据同步」、使用「官方付费插件」无限制等服务。</p>
<h3 id="购买-utools-会员后可以开发票吗" tabindex="-1"><a class="header-anchor" href="#购买-utools-会员后可以开发票吗" aria-hidden="true">#</a> 购买 uTools 会员后可以开发票吗？</h3>
<p>我们可以提供普通电子发票，支付成功后，将开票信息、支付记录截图发送邮件至 service@u.tools ，我们一般会在 3 个工作日内开具，然后通过电子邮箱回复给您。</p>
<h3 id="可以在公司环境使用吗" tabindex="-1"><a class="header-anchor" href="#可以在公司环境使用吗" aria-hidden="true">#</a> 可以在公司环境使用吗？</h3>
<p>可以在任意环境使用 uTools 官网提供的公开版本，无须获得额外的授权。</p>
<h3 id="为什么任务管理器中会有这么多名为「utools」的进程" tabindex="-1"><a class="header-anchor" href="#为什么任务管理器中会有这么多名为「utools」的进程" aria-hidden="true">#</a> 为什么任务管理器中会有这么多名为「uTools」的进程？</h3>
<p>这些进程大部分为 uTools 的插件进程，uTools 的每个插件都会创建一个独立的进程来运行，目的是为了避免一个插件运行出错后导致其他插件甚至整个软件无法使用。</p>
<blockquote>
<p>在uTools主输入框输入<code>clear</code>，可以清理所有正在运行的插件.</p>
</blockquote>
<h3 id="安装时遇到了「进度条卡在一半」的情况怎么办" tabindex="-1"><a class="header-anchor" href="#安装时遇到了「进度条卡在一半」的情况怎么办" aria-hidden="true">#</a> 安装时遇到了「进度条卡在一半」的情况怎么办？<Badge text="Windows"/></h3>
<p>导致这个问题的原因可能是由于旧版本的 uTools 未卸载干净，可尝试按照以下步骤进行处理。</p>
<ol>
<li>检查「程序与功能」界面中是否还有旧版本 uTools 安装项存在，如果存在旧版本，先卸载旧版本再重新安装新版本 uTools。</li>
<li>注册表残留问题 参考 <a href="https://yuanliao.info/d/2030" target="_blank" rel="noopener noreferrer">https://yuanliao.info/d/2030<ExternalLinkIcon/></a></li>
<li>检查 uTools 安装程序是否被「360」、「火绒」等杀毒软件阻止安装，请将 uTools 安装程序放入杀毒软件白名单后再重新安装新版本 uTools。</li>
</ol>
<h3 id="utools-是否会开源" tabindex="-1"><a class="header-anchor" href="#utools-是否会开源" aria-hidden="true">#</a> uTools 是否会开源？</h3>
<p>uTools 为商业软件，暂无开源计划。</p>
</template>
