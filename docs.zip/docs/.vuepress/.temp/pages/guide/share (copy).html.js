export const data = {
  "key": "v-404dd45d",
  "path": "/guide/share%20(copy).html",
  "title": "限时活动",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "【活动】uTools 推荐计划",
      "slug": "【活动】utools-推荐计划",
      "children": []
    },
    {
      "level": 2,
      "title": "【征文】秀出心得，获得免费会员",
      "slug": "【征文】秀出心得-获得免费会员",
      "children": []
    }
  ],
  "filePathRelative": "guide/share (copy).md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
