<template><h1 id="如何与我们合作" tabindex="-1"><a class="header-anchor" href="#如何与我们合作" aria-hidden="true">#</a> 如何与我们合作？</h1>
<p>感谢您对 uTools 的支持，如您有兴趣与 uTools 合作，请您根据希望的合作方式，附上下列信息，来信至： service@u.tools。收到您的邀约后，我们会再进一步与您洽谈。</p>
<p>目前，我们主要接受的合作方式有以下两种：</p>
<h3 id="活动赞助" tabindex="-1"><a class="header-anchor" href="#活动赞助" aria-hidden="true">#</a> 活动赞助</h3>
<p>您想举办任何「线上、线下活动」，需要 uTools 的赞助吗？我们可以提供赞助奖励，让您可将我们的产品、折扣序号等用于公众号抽奖、福利等用途。如须活动赞助，请您附上：</p>
<ol>
<li>活动相关信息、文宣</li>
<li>产品曝光方式</li>
<li>商品赞助所需用途及数量</li>
</ol>
<h3 id="商业合作" tabindex="-1"><a class="header-anchor" href="#商业合作" aria-hidden="true">#</a> 商业合作</h3>
<p>您有任何合作的想法，可以让 uTools 和您互惠、共同成长的吗？欢迎您与我们进一步洽谈！为节省来往时间，希望来信时可以附上：</p>
<ol>
<li>贵公司名称、网站</li>
<li>希望与 uTools 合作的原因</li>
<li>贵公司或您预想的合作模式、产品预计于哪些平台上架？</li>
<li>合作过程中 uTools 可以取用的资源有哪些？</li>
</ol>
</template>
