export const data = {
  "key": "v-7bb1f374",
  "path": "/guide/share.html",
  "title": "限时活动",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "【活动一】uTools 推荐计划",
      "slug": "【活动一】utools-推荐计划",
      "children": [
        {
          "level": 3,
          "title": "计划详情",
          "slug": "计划详情",
          "children": []
        },
        {
          "level": 3,
          "title": "计算原理",
          "slug": "计算原理",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "【活动二】秀心得，获得免费会员",
      "slug": "【活动二】秀心得-获得免费会员",
      "children": [
        {
          "level": 3,
          "title": "撰写你的原创深度心得文章",
          "slug": "撰写你的原创深度心得文章",
          "children": []
        },
        {
          "level": 3,
          "title": "活动流程：",
          "slug": "活动流程",
          "children": []
        },
        {
          "level": 3,
          "title": "评审原则与配分",
          "slug": "评审原则与配分",
          "children": []
        },
        {
          "level": 3,
          "title": "奖励",
          "slug": "奖励",
          "children": []
        },
        {
          "level": 3,
          "title": "注意事项",
          "slug": "注意事项",
          "children": []
        }
      ]
    }
  ],
  "filePathRelative": "guide/share.md"
}
