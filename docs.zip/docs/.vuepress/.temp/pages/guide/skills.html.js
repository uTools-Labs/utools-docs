export const data = {
  "key": "v-7745d56b",
  "path": "/guide/skills.html",
  "title": "使用技巧",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "ESC 键 快速回到主输入框",
      "slug": "esc-键-快速回到主输入框",
      "children": []
    },
    {
      "level": 2,
      "title": "窗口分离",
      "slug": "窗口分离",
      "children": []
    },
    {
      "level": 2,
      "title": "自动识别",
      "slug": "自动识别",
      "children": []
    },
    {
      "level": 2,
      "title": "使用「管理员」权限运行软件",
      "slug": "使用「管理员」权限运行软件",
      "children": []
    },
    {
      "level": 2,
      "title": "将绿色软件加入到 uTools 快速搜索",
      "slug": "将绿色软件加入到-utools-快速搜索",
      "children": []
    },
    {
      "level": 2,
      "title": "全局快捷键",
      "slug": "全局快捷键",
      "children": []
    },
    {
      "level": 2,
      "title": "数据同步",
      "slug": "数据同步",
      "children": []
    }
  ],
  "filePathRelative": "guide/skills.md"
}
