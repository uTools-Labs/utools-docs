export const data = {
  "key": "v-134158a8",
  "path": "/guide/enterprise.html",
  "title": "企业服务",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 3,
      "title": "企业定制版",
      "slug": "企业定制版",
      "children": []
    },
    {
      "level": 3,
      "title": "企业内网部署",
      "slug": "企业内网部署",
      "children": []
    }
  ],
  "filePathRelative": "guide/enterprise.md"
}
