<template><h1 id="使用技巧" tabindex="-1"><a class="header-anchor" href="#使用技巧" aria-hidden="true">#</a> 使用技巧</h1>
<h2 id="esc-键-快速回到主输入框" tabindex="-1"><a class="header-anchor" href="#esc-键-快速回到主输入框" aria-hidden="true">#</a> ESC 键 快速回到主输入框</h2>
<p>在任何进入插件后，可以通过 <code>esc</code> 快速回到初始状态。</p>
<h2 id="窗口分离" tabindex="-1"><a class="header-anchor" href="#窗口分离" aria-hidden="true">#</a> 窗口分离</h2>
<p>uTools 插件都自带图形界面，或许有些时候你希望长时间使用某个插件，或是希望同时开启多个相同的插件，这个时候，你只需按 <code>ctrl + d</code>（ mac 下 <code>command + d</code> ），即可以将插件脱离 uTools 主输入框，把插件当成一个独立的应用程序来使用。</p>
<h2 id="自动识别" tabindex="-1"><a class="header-anchor" href="#自动识别" aria-hidden="true">#</a> 自动识别</h2>
<p>安装对应的插件后，uTools 可以自动识别文本格式，并列出能够处理此文本的插件供你选择。</p>
<p>例如：</p>
<ul>
<li>通过超级面板划词翻译：<code>复制一段英文</code>-&gt;<code>通过长按右键或者中键唤出超级面板</code>-&gt;<code>选择「翻译」插件</code>-&gt;<code>松开鼠标按键得到结果</code>。</li>
<li>通过输入框编辑  JSON ：<code>复制一段 json 字符串</code>-&gt;<code>呼出 uTools (会自动粘贴)</code>-&gt;<code>选择「 json 」插件</code>-&gt;<code>得到结果</code>。</li>
</ul>
<h2 id="使用「管理员」权限运行软件" tabindex="-1"><a class="header-anchor" href="#使用「管理员」权限运行软件" aria-hidden="true">#</a> 使用「管理员」权限运行软件 <Badge text="Windows"/></h2>
<p>在 uTools 列表里选中要打开的软件，使用快捷键 <code>Ctrl + 回车（Enter）</code>打开即可。</p>
<h2 id="将绿色软件加入到-utools-快速搜索" tabindex="-1"><a class="header-anchor" href="#将绿色软件加入到-utools-快速搜索" aria-hidden="true">#</a> 将绿色软件加入到 uTools 快速搜索</h2>
<p>uTools 默认无法搜索到免安装的绿色软件，你可以手动加入。找到该绿色软件的主程序，复制后呼出 uTools 输入框或拖动该文件到 uTools 输入框中，即可看到加入「本地文件启动」的选项，确认后可在 uTools 列表中搜索到该软件。（文件和文件夹也可以添加）</p>
<h2 id="全局快捷键" tabindex="-1"><a class="header-anchor" href="#全局快捷键" aria-hidden="true">#</a> 全局快捷键</h2>
<p>uTools 已经可以快速的辅助你解决一些小场景的问题，但是在使用很频繁的一些场景，合理的使用全局快捷键可以一键直达，快上加快。</p>
<p>首先，你需要在「 setting 」中配置全局快捷键，事例如下图：
<img src="https://res.u-tools.cn/images/1675676326422.png" style="zoom:50%;" /></p>
<ul>
<li>例：设置 <code>F1 </code> 为「百度」功能，在任何界面下按 <code>F1</code> 可快速进行百度搜索。</li>
</ul>
<p>更多玩法等你探索</p>
<h2 id="数据同步" tabindex="-1"><a class="header-anchor" href="#数据同步" aria-hidden="true">#</a> 数据同步</h2>
<p>uTools 是一个桌面应用程序，各插件所产生配置、内容都将保存在你本地数据库中。</p>
<p>但是你可能需要在公司、家里不同的设备上面使用 uTools ，或者为了预防重装系统等原因造成数据丢失。我们特别准备了云端实时同步备份服务，你可以在成为 uTools 会员 之后进入「设置」自助开启。</p>
</template>
