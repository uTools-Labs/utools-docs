export const data = {
  "key": "v-654983d1",
  "path": "/guide/ppt.html",
  "title": "向团队介绍 uTools",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 3,
      "title": "播放 uTools 介绍视频",
      "slug": "播放-utools-介绍视频",
      "children": []
    },
    {
      "level": 3,
      "title": "分享过程中可供使用的 PPT",
      "slug": "分享过程中可供使用的-ppt",
      "children": []
    },
    {
      "level": 3,
      "title": "演示你在工作中如何使用 uTools",
      "slug": "演示你在工作中如何使用-utools",
      "children": []
    }
  ],
  "filePathRelative": "guide/ppt.md"
}
