export const data = {
  "key": "v-37e1c06f",
  "path": "/guide/faq.html",
  "title": "常见问题",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 3,
      "title": "安装时遇到了「无法打开 uTools，因为 Apple 无法检查是否包含恶意软体」的情况怎么办？",
      "slug": "安装时遇到了「无法打开-utools-因为-apple-无法检查是否包含恶意软体」的情况怎么办",
      "children": []
    },
    {
      "level": 3,
      "title": "uTools 会收费吗？",
      "slug": "utools-会收费吗",
      "children": []
    },
    {
      "level": 3,
      "title": "购买 uTools 会员后可以开发票吗？",
      "slug": "购买-utools-会员后可以开发票吗",
      "children": []
    },
    {
      "level": 3,
      "title": "可以在公司环境使用吗？",
      "slug": "可以在公司环境使用吗",
      "children": []
    },
    {
      "level": 3,
      "title": "为什么任务管理器中会有这么多名为「uTools」的进程？",
      "slug": "为什么任务管理器中会有这么多名为「utools」的进程",
      "children": []
    },
    {
      "level": 3,
      "title": "安装时遇到了「进度条卡在一半」的情况怎么办？",
      "slug": "安装时遇到了「进度条卡在一半」的情况怎么办",
      "children": []
    },
    {
      "level": 3,
      "title": "uTools 是否会开源？",
      "slug": "utools-是否会开源",
      "children": []
    }
  ],
  "filePathRelative": "guide/faq.md"
}
