export const data = {
  "key": "v-91418c92",
  "path": "/guide/enterprise%20(copy).html",
  "title": "企业服务",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 3,
      "title": "企业定制版",
      "slug": "企业定制版",
      "children": []
    },
    {
      "level": 3,
      "title": "企业内网部署",
      "slug": "企业内网部署",
      "children": []
    }
  ],
  "filePathRelative": "guide/enterprise (copy).md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
