<template><h1 id="企业服务" tabindex="-1"><a class="header-anchor" href="#企业服务" aria-hidden="true">#</a> 企业服务</h1>
<p>uTools 致力于打造一个高效的工具平台，通过轻量化的插件解决重复性的问题，提高工作效率。针对企业用户提供以下服务，如有需要可以联系 service@u.tools 进一步洽谈。</p>
<h3 id="企业定制版" tabindex="-1"><a class="header-anchor" href="#企业定制版" aria-hidden="true">#</a> 企业定制版</h3>
<ol>
<li>
<p><strong>插件定制开发</strong></p>
<p>连接 uTools 的优秀插件开发者，可以根据企业特殊需求定制开发插件</p>
</li>
<li>
<p><strong>企业后台管理</strong></p>
<p>自定义插件列表，企业成员管理，权限管理等</p>
</li>
<li>
<p><strong>独立服务器</strong></p>
<p>独享服务器保证服务的稳定性及私密性</p>
</li>
<li>
<p><strong>培训及技术支持</strong></p>
<p>专属团队及时响应，提供使用/插件开发培训，解决企业的各种问题</p>
</li>
</ol>
<h3 id="企业内网部署" tabindex="-1"><a class="header-anchor" href="#企业内网部署" aria-hidden="true">#</a> 企业内网部署</h3>
<p>包含企业定制版的所有功能，如果您的企业有更高的安全要求，或内部网络无法访问公网，可以选择企业内网部署，数据传输更加迅速，团队使用更高效和安全。</p>
</template>
