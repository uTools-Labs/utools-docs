export const data = {
  "key": "v-05cab828",
  "path": "/README%20copy.html",
  "title": "",
  "lang": "zh",
  "frontmatter": {
    "home": false,
    "heroImage": "https://i.loli.net/2018/12/27/5c24c4fc1ea16.png",
    "heroText": "uTools",
    "tagline": "自由配置插件，打造你的专属工具集",
    "actionText": "快速上手 →",
    "actionLink": "/guide/about-uTools",
    "pageClass": "custom-logo",
    "features": [
      {
        "title": "自由扩展",
        "details": "uTools拥有强大的插件扩展能力，自由组合所需要的插件。让你得心应手，事半功倍。"
      },
      {
        "title": "自动识别",
        "details": "uTools支持多种输入源呼出插件，例如：字符输入、文件拖拽、截图粘贴，亦能够自动识别输入内容进入相应插件，如json、时间戳、base64等。"
      },
      {
        "title": "数据同步",
        "details": "uTools各插件产生的数据将保存到本地数据库中。为了便于在不同设备之间共享数据，或是预防造成数据丢失，我们提供云端数据备份同步服务。"
      }
    ],
    "footer": "Copyright © 2018-present u.tools"
  },
  "excerpt": "",
  "headers": [],
  "filePathRelative": "README copy.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
