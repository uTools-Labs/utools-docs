export const data = {
  "key": "v-40fe6f2e",
  "path": "/media.html",
  "title": "媒体资源",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 3,
      "title": "播放 uTools 介绍视频",
      "slug": "播放-utools-介绍视频",
      "children": []
    },
    {
      "level": 3,
      "title": "分享过程中可供使用的 PPT",
      "slug": "分享过程中可供使用的-ppt",
      "children": []
    },
    {
      "level": 3,
      "title": "演示你在工作中如何使用 uTools",
      "slug": "演示你在工作中如何使用-utools",
      "children": []
    }
  ],
  "filePathRelative": "media.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
