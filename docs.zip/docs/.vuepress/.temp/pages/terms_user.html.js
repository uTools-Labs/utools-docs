export const data = {
  "key": "v-76c241c6",
  "path": "/terms_user.html",
  "title": "uTools 用户协议",
  "lang": "zh",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "terms_user.md"
}
